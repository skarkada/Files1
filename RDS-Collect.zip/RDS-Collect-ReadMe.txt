================
IMPORTANT NOTICE 
================
 
This script is designed to collect information that will help Microsoft Customer Support Services (CSS) troubleshoot an issue you may be experiencing with Remote Desktop Services.

The collected data may contain Personally Identifiable Information (PII) and/or sensitive data, such as (but not limited to) IP addresses, PC names and user names.

The script will save the collected data in a subfolder and also compress the results into a ZIP file. The folder or ZIP file are not automatically sent to Microsoft. 

You can send the ZIP file to Microsoft CSS using a secure file transfer tool - Please discuss this with your support professional and also any concerns you may have. 

Find our privacy statement here: https://privacy.microsoft.com/en-US/privacystatement


===================================
How to use RDS-Collect (v210824.2)
===================================

The script must be run with elevated permissions in order to collect all required data.
All collected data will be archived into a .zip file located in the same folder as the script itself.
Run the script on any Windows based device where you want to collect data for RDS/RDP troubleshooting scenarios.

When launched, the script will present the Microsoft Diagnostic Tools End User License Agreement (EULA). You need to accept the EULA before you can continue using the script.
Acceptance of the EULA will be stored in the registry under HKCU\Software\Microsoft\CESDiagnosticTools and you will not be prompted again to accept it as long as the registry key is in place.
You can also use the "-AcceptEula" command line parameter to silently accept the EULA.
This is a per user setting, so each user running the script will have to accept the EULA once.

When launched without any command line parameter, the script will ask you to select one of the following five scenarios:

	"Core" (suitable for troubleshooting issues that do not involve Profiles or MSRA data)
		* Collects core troubleshooting data without including Profiles/FSLogix or MSRA
		* Runs Diagnostics. Diagnostics results will be logged

	"Core + Profiles" (suitable for troubleshooting Profiles issues)
		​​​​​​​* Collects all Core data	
		* Collects Profiles/FSLogix related information, as available
		* Runs Diagnostics. Diagnostics results will be logged

	"Core + MSRA" (suitable for troubleshooting Remote Assistance issues)
		* Collects all Core data
		* Collects Remote Assistance related information, as available
		* Runs Diagnostics. Diagnostics results will be logged

	"Extended (all)" (suitable for troubleshooting most issues, including Profiles/FSLogix and MSRA)
		* Collects all Core data
		* Collects Profiles/FSLogix related information, as available
		* Collects MSRA related information, as available
		* Runs Diagnostics. Diagnostics results will be logged

	"DiagOnly"
​​​​​​​		* Skips all Core/Extended data collection and runs Diagnostics only (regardless if any other parameters have been specified)
		* Runs Diagnostics. Diagnostics results will be logged

The default scenario is "Core".​​​​​​​



Available command line parameters (to preselect the desired scenario)
---------------------------------------------------------------------

	"-Core" - Collects Core data

	"-Profiles" - Collects all Core data + Profiles/FSLogix data

	"-MSRA" - Collects all Core data + Remote Assistance data

	"-Extended" - Collects all Core data + Extended (Profiles/FSLogix, MSRA) data

	"-DiagOnly" - The script will skip all data collection and will only run the diagnostics part (even if other parameters have been included).

	"-AcceptEula" - Silently accepts the Microsoft Diagnostic Tools End User License Agreement


Usage example with parameters:

To collect only Core data (excluding Profiles/FSLogix, MSRA):
	.\RDS-Collect.ps1 -Core

To collect Core + Extended data (incl. Profiles/FSLogix, MSRA):
	.\RDS-Collect.ps1 -Extended

To collect Core + Profiles data 
	.\RDS-Collect.ps1 -Profiles


​​​​​​​If you are missing any of the data that the script should normally collect (see "Data being collected"), check the content of "*_RDS-Collect-Log.txt" and "*_RDS-Collect-Errors.txt" files for more information. Some data may not be present during data collection and thus not picked up by the script. This should be visible in one of the two text files.



PowerShell ExecutionPolicy
--------------------------

If the script does not start, complaining about execution restrictions, then in an elevated PowerShell console run:

	Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Force -Scope Process

and verify with "Get-ExecutionPolicy -List" that no ExecutionPolicy with higher precedence is blocking execution of this script.
The script is digitally signed with a Microsoft Code Sign certificate.

After that run the RDS-Collect script again.


Once the script has started, p​​​lease read the "IMPORTANT NOTICE" message and confirm if you agree to continue with the data collection.

Depending on the amount of data that needs to be collected, the script may need run for a few minutes. Please wait until the script finishes collecting all the data.



====================
Data being collected
====================

The collected data is stored in a subfolder under the same folder where the script is located and at the end of the data collection, the results are archived into a .zip file. No data is automatically uploaded to Microsoft.
The script collects the following set of data, as available, also based on the selected scenario or command line parameter used:

• Membership information for the following groups:
	o Offer Remote Assistance Helpers
	o RDS Management Servers
	o RDS Remote Access Servers
	o RDS Endpoint Servers
	o Remote Desktop Users​​
	o FSLogix ODFC Exclude List
	o FSLogix ODFC Include List
	o FSLogix Profile Exclude List
	o FSLogix Profile Include List
• Registry keys:
	o HKEY_CURRENT_USER\Control Panel\International
	o HKEY_CURRENT_USER\Keyboard Layout
	o HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\NET Framework Setup\NDP
	o HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Terminal Server Client
	o HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies
	o ​​​​​​​HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Run
	o HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\ProfileList
	o HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Terminal Server
	o HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Cryptography
	o HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation
	o HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services
	o HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Cryptography
	o HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Lsa
	o HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Remote Assistance
	o HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\SecurityProviders
	o HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Terminal Server​​
	o HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\TermService
	o HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\UmRdpService
	o HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\WinRM​​
	o HKEY_LOCAL_MACHINE\SYSTEM\Keyboard Layout
• Event Logs:
	o Application
	o Microsoft-Windows-CAPI2 (Operational)
	o Microsoft-Windows-Rdms-UI (Admin and Operational)
	o Microsoft-Windows-Remote-Desktop-Management-Service (Admin and Operational)
	o Microsoft-Windows-RemoteApp and Desktop Connection Management (Admin and Operational)
	o Microsoft-Windows-RemoteApp and Desktop Connections (Admin and Operational)
	o Microsoft-Windows-RemoteAssistance (Admin + Operational)​
	o Microsoft-Windows-RemoteDesktopServices-RdpCoreCDV (Admin + Operational)
	o Microsoft-Windows-RemoteDesktopServices-RdpCoreTS (Admin + Operational)
	o Microsoft-Windows-TaskScheduler/Operational
	o Microsoft-Windows-SMBClient (Connectivity + Operational + Security)
	o Microsoft-Windows-SMBServer (Connectivity + Operational + Security)
	o Microsoft-Windows-TerminalServices-ClientUSBDevices (Admin and Operational)
	o Microsoft-Windows-TerminalServices-Gateway (Admin and Operational)
	o Microsoft-Windows-TerminalServices-Licensing (Admin and Operational)
	o Microsoft-Windows-TerminalServices-LocalSessionManager (Admin + Operational)
	o Microsoft-Windows-TerminalServices-PnPDevices (Admin + Operational)
	o Microsoft-Windows-TerminalServices-Printers (Admin and Operational)
	o Microsoft-Windows-TerminalServices-RDPClient/Operational
	o Microsoft-Windows-TerminalServices-RemoteConnectionManager (Admin + Operational)
	o Microsoft-Windows-TerminalServices-ServerUSBDevices (Admin and Operational)
	o Microsoft-Windows-TerminalServices-SessionBroker (admin and Operational)
	o Microsoft-Windows-TerminalServices-SessionBroker-Client (admin and Operational)
	o Microsoft-Windows-TerminalServices-TSAppSrv-TSMSI (admin and Operational)
	o Microsoft-Windows-TerminalServices-TSAppSrv-TSVIP (admin and Operational)
	o Microsoft-Windows-User Profile Service (Operational)
	o Microsoft-Windows-VHDMP (Operational)
	o Microsoft-Windows-WinINet-Config/ProxyConfigChanged
	o Microsoft-Windows-WinRM/Operational
	o Microsoft-FSLogix-Apps/Admin
	o Microsoft-FSLogix-Apps/Operational
	o Microsoft-FSLogix-CloudCache/Admin
	o Microsoft-FSLogix-CloudCache/Operational
	o Security
	o System
• "Gpresult /h" output
• "Gpresult /r /z" output
• "Qwinsta /counter" output
• Details of the running processes and services
• Networking information (profiles, firewall rules, netstat -anob, ipconfig /all, proxy settings)
• PowerShell version
• .NET Framework information
• Msinfo32 output
• Certificate and thumbprint information ("My" and "Remote Desktop")
• Get-Hotfix output
• DxDiag output in .txt format with no WHQL check
• File versions of the running and some key binaries
• Basic system information
• DACLs for "C:\ProgramData\Microsoft\Crypto\RSA\MachineKeys" and "C:\ProgramData\Microsoft\Crypto\RSA\MachineKeys\f686aace6942fb7f7ceb231212eef4a4_"
• Remote Desktop License Server database information (if RDLS role is installed):
	o Win32_TSLicenseKeyPack
	o Win32_TSIssuedLicense
• RD Gateway information (if RDGW role is installed):
	o Server Settings, Resource Authorization Policy, Connection Authorization Policy, Resource Group, Load Balancing, Gateway RADIUS Server
• RD Connection Broker information (if RDCB role is installed):
	o Workspace, Published Farm, Published Deployment Settings, Published File Association, Personal Desktop Assignment, Session Directory Cluster, RDMS Deployment Settings
• RD Web Access information (if RDWA role is installed):
	o IIS configuration
• FSLogix log files from C:\ProgramData\FSLogix\Logs
• FSLogix registry keys
	o ​​​​​​​HKEY_CURRENT_USER\SOFTWARE\Microsoft\Office​
	o HKEY_CURRENT_USER\SOFTWARE\Microsoft\OneDrive
	o HKEY_CURRENT_USER\SOFTWARE\Policies\Microsoft\Office
	o HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\OneDrive
	o HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Office
	o HKEY_LOCAL_MACHINE\SOFTWARE\FSLogix
	o HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\ProfileList
	o HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows Search
	o HKEY_LOCAL_MACHINE\SOFTWARE\Policies\FSLogix
	o HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows Defender\Exclusions\Extensions
	o HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows Defender\Exclusions\Paths
	o HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows Defender\Exclusions\Processes
	o HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows Defender\Exclusions\Extensions
	o HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows Defender\Exclusions\Paths
	o HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows Defender\Exclusions\Processes
	o HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Teams\
	o HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\RDWebRTCSvc
• "frx list-redirects" output
• "frx list-rules" output
• "frx version" output​​​​​​​


========
RDS-Diag
========

RDS-Collect also performs diagnostics for some common known issues, regardless of the selected scenario.
Based on your requirements, you may want to skip specific data collection or run diagnostics only. See the scenario descriptions above.
New diagnostics checks may be added in each new release, so make sure to always use the latest version of the script.​​​​​​​

Important Notes:
"Diagnostics" is not a replacement of a full data analysis. It is only meant to give you basic diagnostics of some common scenarios and to ease further troubleshooting. Depending on the scenario, further data collection and analysis will be needed.

Version 210824.2 of the script can perform the following diagnostics:

• Brief check of the system the script is running on (from RDS point of view): FQDN, OS, OS Build, uptime
	o Check for last machine boot up time, with an extra notification if it occurred >= 25 hours ago
	o Check for "LmCompatibilityLevel" registry key value
	o Check for Time Zone Redirection policy configuration
• Check for installed RDS roles
• Check for licensing configuration for Session Hosts (License Servers and Licensing Mode)
• Check for graphics configuration (checks recommended policy configuration and lists available video controllers and their driver versions)
• Check the status of key services: TermService, SessionEnv, UmRdpService, AppReadiness, AppXSvc, WinRM, frxsvc, frxdrv, frxccds, msiserver (Windows Installer)
• Check for the RDP-Tcp listener availability and configuration
• Check for Session Time Limit policy settings
• Check for device and resource redirection policy configuration
• Check for camera and microphone privacy settings (general and desktop apps)
• Check for proxy settings
• Check for Process crashes that occurred within the last 5 days
• Check if reg key "HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows Defender\DisableAntiSpyware" is enabled on Server OS
• Check for FSLogix best practice settings for enterprises
• Check for FSLogix registry key "HKLM\SOFTWARE\FSLogix\Profiles\NoProfileContainingFolder"
• Check for "frxsvc" service recovery settings
• Check for Cloud Cache "CCDLocations" registry key for Profile and Office Container
• Check the availability and value of the "CleanupInvalidSessions" registry key when FSLogix is present on the system
• Check for the presence of the recommended Windows Defender Antivirus exclusion values when FSLogix is present on the system
• Check OneDrive configuration/requirements when FSLogix is present on the system
• Check the values of the following additional registry keys: 
	o HKEY_LOCAL_MACHINE\System\CurrentControlSet\Control\Terminal Server\fDenyTSConnections
	o HKEY_LOCAL_MACHINE\SYSTEM\Setup\OOBEInProgress
	o HKEY_LOCAL_MACHINE\System\CurrentControlSet\Control\Terminal Server\fSingleSessionPerUser
	o HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services\fQueryUserConfigFromDC
	o HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Cryptography\Configuration\SSL\00010002\Functions (SSL Cipher Suite Order)
	o HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Cryptography\Configuration\SSL\00010002\EccCurves
	o HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\DeleteUserAppContainersOnLogoff (for the firewall rules bloating scenario)
• Check WinRM configuration / requirements
	o ​​​​​​​Presence of "WinRMRemoteWMIUsers__" group
	o IPv4Filter and IPv6Filter values
	o Presence of firewall rules for ports 5985 and 5986

The script generates a *_RDS-Diag.txt and a *_RDS-Diag.html output file with the results of the above checks. Additional output files may be generated if process crashes have been identified.


==========
Tool Owner
==========
Robert Viktor Klemencz @ Microsoft Customer Service and Support
If you have any feedback about the tool or want to report any issues with it, please reach out to RDSCollectTalk@microsoft.com

