﻿<#
    .SYNOPSIS
    Simplify data collection for troubleshooting Remote Desktop Services issues and a convenient method for submitting and following quick & easy action plans.

    .DESCRIPTION
    This script is designed to collect information that will help Microsoft Customer Support Services (CSS) troubleshoot an issue you may be experiencing with Remote Desktop Services.
    The collected data may contain Personally Identifiable Information (PII) and/or sensitive data, such as (but not limited to) IP addresses; PC names; and user names.
    The script will save the collected data in a folder and also compress the results into a ZIP file, both in the same location from where the script has been launched.
    This folder and its contents or the ZIP file are not automatically sent to Microsoft.
    You can send the ZIP file to Microsoft CSS using a secure file transfer tool - Please discuss this with your support professional and also any concerns you may have.
    Find our privacy statement here: https://privacy.microsoft.com/en-US/privacystatement

    Run 'Get-Help RDS-Collect.ps1 -Full' for more details.

    USAGE SUMMARY:

    The script must be run with elevated permissions in order to collect all required data.

    When launched without any command line parameter, you can select one of the available data collection/diagnostics scenarios. Diagnostics will run for every scenario.

    1: Collect 'Core' data + Run Diagnostics
    2: Collect 'Core + Profiles' data + Run Diagnostics
    3: Collect 'Core + Remote Assistance' data + Run Diagnostics
    4: Collect 'Extended' diagnostic data (Core + all other categories) + Run Diagnostics
    5: Run 'Diagnostics' only (skip data collection - may still log process crash related events, if found)

    If you want to combine multiple scenarios or skip having to manually select a scenario, use command line parameters.

    .NOTES
    Author           : Robert Viktor Klemencz (Microsoft CSS)
    Requires         : At least PowerShell 5.1 and to be run elevated
    Last update      : August 24th, 2021
    Version          : 210824.2
    Feedback         : For any script related feedback please send an e-mail to RDSCollectTalk@microsoft.com

    .PARAMETER Core
    Collect only basic RDS data (without Profiles/FSLogix/MSRA related information). Diagnostics will run at the end.

    .PARAMETER Profiles
    Collect Core + Profiles/FSLogix related data. Diagnostics will run at the end.

    .PARAMETER MSRA
    Collect Core + Remote Assistance related data. Diagnostics will run at the end.
    
    .PARAMETER Extended
    Collect all the basic RDS data, plus Profiles/FSLogix and MSRA related information. Diagnostics will run at the end.
    If the script is launched with both "-Core" and "-Extended" parameters at the same time, the higher ("-Extended") parameter will be applied.

    .PARAMETER DiagOnly
    Skip collecting troubleshooting data (even if any other parameters are specificed) and will only perform diagnostics. The results of the diagnostics will be stored in the 'RDS-Diag.txt' and 'RDS-Diag.html' files.
    If process crash events have been detected over the past 5 days, information about these process crashes will be logged under 'RDS-Diag-ProcessCrashEvents.txt'.

    .PARAMETER AcceptEula
    Silently accepts the Microsoft Diagnostic Tools End User License Agreement.

    .OUTPUTS
    By default, all collected data are stored in a subfolder in the same location from where the tool was launched.
#>


param ([switch]$Core = $false, [switch]$Extended = $false, [switch]$Profiles = $false, [switch]$MSRA = $false, [switch]$AcceptEula, [switch]$DiagOnly = $false)

$version = "210824.2"
$myWindowsID = [System.Security.Principal.WindowsIdentity]::GetCurrent()
$myWindowsPrincipal = new-object System.Security.Principal.WindowsPrincipal($myWindowsID)
$adminRole = [System.Security.Principal.WindowsBuiltInRole]::Administrator
if (-not $myWindowsPrincipal.IsInRole($adminRole)) {
    Write-Host "This script needs to be run as Administrator" -ForegroundColor Yellow
    exit
}


#region ####################### Initializing ########################
$LogRoot = Split-Path (Get-Variable MyInvocation).Value.MyCommand.Path
$LogFolder = "RDS-Results-" + $env:computername +"-" + $(get-date -f yyyyMMdd_HHmmss)
$LogDir = "$LogRoot\$LogFolder\"
$LogFilePrefix = $env:computername + "_"

New-Item -itemtype directory -path $LogDir | Out-Null

$BasicLogFolder = "$LogDir$env:computername" + "_"
$CertLogFolder = $BasicLogFolder + "Certificates\"
$EventLogFolder = $BasicLogFolder + "EventLogs\"
$NetLogFolder = $BasicLogFolder + "Networking\"
$RegLogFolder = $BasicLogFolder + "RegistryKeys\"
$SysInfoLogFolder = $BasicLogFolder + "SystemInfo\"
$FSLogixLogFolder = $BasicLogFolder + "FSLogix\"
$RDSLogFolder = $BasicLogFolder + "RDS\"
$ErrorLogFile = $BasicLogFolder + "RDS-Collect-Error.txt"
$TempCommandErrorFile = $BasicLogFolder + "RDS-Collect-CommandError.txt"
$OutputLogFile = $BasicLogFolder + "RDS-Collect-Log.txt"

$LogLevel = @{
    'Normal' = 0
    'Info' = 1
    'Warning' = 2
    'Error' = 3
    'ErrorLogFileOnly' = 4
    'WarnLogFileOnly' = 5
    'DiagFileOnly' = 7
}

$ver = (Get-CimInstance Win32_OperatingSystem).Caption
$fqdn = [System.Net.Dns]::GetHostByName(($env:computerName)).HostName

$bodyDiag = '<style>
BODY { background-color:#E0E0E0; font-family: sans-serif; font-size: small;}
table { background-color: white; border-collapse:collapse; border: 1px solid black; padding: 10px; margin-left:auto; margin-right:auto;}
td { padding-left: 10px; padding-right: 10px; }
</style>'

$bodyRDLS = '<style>
BODY { background-color:#E0E0E0; font-family: sans-serif; font-size: small;}
table { background-color: white; border-collapse:collapse; border: 1px solid black; padding: 10px;}
td { padding-left: 10px; padding-right: 10px; }
</style>'

Set-Variable -Name 'fLogFileOnly' -Value $True -Option readonly

#endregion Initializing


#region ####################### Functions ########################

#region Internal functions

[void][System.Reflection.Assembly]::Load('System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a')
[void][System.Reflection.Assembly]::Load('System.Windows.Forms, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089')

function ShowEULAPopup($mode)
{
    $EULA = New-Object -TypeName System.Windows.Forms.Form
    $richTextBox1 = New-Object System.Windows.Forms.RichTextBox
    $btnAcknowledge = New-Object System.Windows.Forms.Button
    $btnCancel = New-Object System.Windows.Forms.Button

    $EULA.SuspendLayout()
    $EULA.Name = "EULA"
    $EULA.Text = "Microsoft Diagnostic Tools End User License Agreement"

    $richTextBox1.Anchor = [System.Windows.Forms.AnchorStyles]::Top -bor [System.Windows.Forms.AnchorStyles]::Bottom -bor [System.Windows.Forms.AnchorStyles]::Left -bor [System.Windows.Forms.AnchorStyles]::Right
    $richTextBox1.Location = New-Object System.Drawing.Point(12,12)
    $richTextBox1.Name = "richTextBox1"
    $richTextBox1.ScrollBars = [System.Windows.Forms.RichTextBoxScrollBars]::Vertical
    $richTextBox1.Size = New-Object System.Drawing.Size(776, 397)
    $richTextBox1.TabIndex = 0
    $richTextBox1.ReadOnly=$True
    $richTextBox1.Add_LinkClicked({Start-Process -FilePath $_.LinkText})
    $richTextBox1.Rtf = @"
{\rtf1\ansi\ansicpg1252\deff0\nouicompat{\fonttbl{\f0\fswiss\fprq2\fcharset0 Segoe UI;}{\f1\fnil\fcharset0 Calibri;}{\f2\fnil\fcharset0 Microsoft Sans Serif;}}
{\colortbl ;\red0\green0\blue255;}
{\*\generator Riched20 10.0.19041}{\*\mmathPr\mdispDef1\mwrapIndent1440 }\viewkind4\uc1 
\pard\widctlpar\f0\fs19\lang1033 MICROSOFT SOFTWARE LICENSE TERMS\par
Microsoft Diagnostic Scripts and Utilities\par
\par
{\pict{\*\picprop}\wmetafile8\picw26\pich26\picwgoal32000\pichgoal15 
0100090000035000000000002700000000000400000003010800050000000b0200000000050000
000c0202000200030000001e000400000007010400040000000701040027000000410b2000cc00
010001000000000001000100000000002800000001000000010000000100010000000000000000
000000000000000000000000000000000000000000ffffff00000000ff040000002701ffff0300
00000000
}These license terms are an agreement between you and Microsoft Corporation (or one of its affiliates). IF YOU COMPLY WITH THESE LICENSE TERMS, YOU HAVE THE RIGHTS BELOW. BY USING THE SOFTWARE, YOU ACCEPT THESE TERMS.\par
{\pict{\*\picprop}\wmetafile8\picw26\pich26\picwgoal32000\pichgoal15 
0100090000035000000000002700000000000400000003010800050000000b0200000000050000
000c0202000200030000001e000400000007010400040000000701040027000000410b2000cc00
010001000000000001000100000000002800000001000000010000000100010000000000000000
000000000000000000000000000000000000000000ffffff00000000ff040000002701ffff0300
00000000
}\par
\pard 
{\pntext\f0 1.\tab}{\*\pn\pnlvlbody\pnf0\pnindent0\pnstart1\pndec{\pntxta.}}
\fi-360\li360 INSTALLATION AND USE RIGHTS. Subject to the terms and restrictions set forth in this license, Microsoft Corporation (\ldblquote Microsoft\rdblquote ) grants you (\ldblquote Customer\rdblquote  or \ldblquote you\rdblquote ) a non-exclusive, non-assignable, fully paid-up license to use and reproduce the script or utility provided under this license (the "Software"), solely for Customer\rquote s internal business purposes, to help Microsoft troubleshoot issues with one or more Microsoft products, provided that such license to the Software does not include any rights to other Microsoft technologies (such as products or services). \ldblquote Use\rdblquote  means to copy, install, execute, access, display, run or otherwise interact with the Software. \par
\pard\widctlpar\par
\pard\widctlpar\li360 You may not sublicense the Software or any use of it through distribution, network access, or otherwise. Microsoft reserves all other rights not expressly granted herein, whether by implication, estoppel or otherwise. You may not reverse engineer, decompile or disassemble the Software, or otherwise attempt to derive the source code for the Software, except and to the extent required by third party licensing terms governing use of certain open source components that may be included in the Software, or remove, minimize, block, or modify any notices of Microsoft or its suppliers in the Software. Neither you nor your representatives may use the Software provided hereunder: (i) in a way prohibited by law, regulation, governmental order or decree; (ii) to violate the rights of others; (iii) to try to gain unauthorized access to or disrupt any service, device, data, account or network; (iv) to distribute spam or malware; (v) in a way that could harm Microsoft\rquote s IT systems or impair anyone else\rquote s use of them; (vi) in any application or situation where use of the Software could lead to the death or serious bodily injury of any person, or to physical or environmental damage; or (vii) to assist, encourage or enable anyone to do any of the above.\par
\par
\pard\widctlpar\fi-360\li360 2.\tab DATA. Customer owns all rights to data that it may elect to share with Microsoft through using the Software. You can learn more about data collection and use in the help documentation and the privacy statement at {{\field{\*\fldinst{HYPERLINK https://aka.ms/privacy }}{\fldrslt{https://aka.ms/privacy\ul0\cf0}}}}\f0\fs19 . Your use of the Software operates as your consent to these practices.\par
\pard\widctlpar\par
\pard\widctlpar\fi-360\li360 3.\tab FEEDBACK. If you give feedback about the Software to Microsoft, you grant to Microsoft, without charge, the right to use, share and commercialize your feedback in any way and for any purpose.\~ You will not provide any feedback that is subject to a license that would require Microsoft to license its software or documentation to third parties due to Microsoft including your feedback in such software or documentation. \par
\pard\widctlpar\par
\pard\widctlpar\fi-360\li360 4.\tab EXPORT RESTRICTIONS. Customer must comply with all domestic and international export laws and regulations that apply to the Software, which include restrictions on destinations, end users, and end use. For further information on export restrictions, visit {{\field{\*\fldinst{HYPERLINK https://aka.ms/exporting }}{\fldrslt{https://aka.ms/exporting\ul0\cf0}}}}\f0\fs19 .\par
\pard\widctlpar\par
\pard\widctlpar\fi-360\li360\qj 5.\tab REPRESENTATIONS AND WARRANTIES. Customer will comply with all applicable laws under this agreement, including in the delivery and use of all data. Customer or a designee agreeing to these terms on behalf of an entity represents and warrants that it (i) has the full power and authority to enter into and perform its obligations under this agreement, (ii) has full power and authority to bind its affiliates or organization to the terms of this agreement, and (iii) will secure the permission of the other party prior to providing any source code in a manner that would subject the other party\rquote s intellectual property to any other license terms or require the other party to distribute source code to any of its technologies.\par
\pard\widctlpar\par
\pard\widctlpar\fi-360\li360\qj 6.\tab DISCLAIMER OF WARRANTY. THE SOFTWARE IS PROVIDED \ldblquote AS IS,\rdblquote  WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL MICROSOFT OR ITS LICENSORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THE SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.\par
\pard\widctlpar\qj\par
\pard\widctlpar\fi-360\li360\qj 7.\tab LIMITATION ON AND EXCLUSION OF DAMAGES. IF YOU HAVE ANY BASIS FOR RECOVERING DAMAGES DESPITE THE PRECEDING DISCLAIMER OF WARRANTY, YOU CAN RECOVER FROM MICROSOFT AND ITS SUPPLIERS ONLY DIRECT DAMAGES UP TO U.S. $5.00. YOU CANNOT RECOVER ANY OTHER DAMAGES, INCLUDING CONSEQUENTIAL, LOST PROFITS, SPECIAL, INDIRECT, OR INCIDENTAL DAMAGES. This limitation applies to (i) anything related to the Software, services, content (including code) on third party Internet sites, or third party applications; and (ii) claims for breach of contract, warranty, guarantee, or condition; strict liability, negligence, or other tort; or any other claim; in each case to the extent permitted by applicable law. It also applies even if Microsoft knew or should have known about the possibility of the damages. The above limitation or exclusion may not apply to you because your state, province, or country may not allow the exclusion or limitation of incidental, consequential, or other damages.\par
\pard\widctlpar\par
\pard\widctlpar\fi-360\li360 8.\tab BINDING ARBITRATION AND CLASS ACTION WAIVER. This section applies if you live in (or, if a business, your principal place of business is in) the United States.  If you and Microsoft have a dispute, you and Microsoft agree to try for 60 days to resolve it informally. If you and Microsoft can\rquote t, you and Microsoft agree to binding individual arbitration before the American Arbitration Association under the Federal Arbitration Act (\ldblquote FAA\rdblquote ), and not to sue in court in front of a judge or jury. Instead, a neutral arbitrator will decide. Class action lawsuits, class-wide arbitrations, private attorney-general actions, and any other proceeding where someone acts in a representative capacity are not allowed; nor is combining individual proceedings without the consent of all parties. The complete Arbitration Agreement contains more terms and is at {{\field{\*\fldinst{HYPERLINK https://aka.ms/arb-agreement-4 }}{\fldrslt{https://aka.ms/arb-agreement-4\ul0\cf0}}}}\f0\fs19 . You and Microsoft agree to these terms. \par
\pard\widctlpar\par
\pard\widctlpar\fi-360\li360 9.\tab LAW AND VENUE. If U.S. federal jurisdiction exists, you and Microsoft consent to exclusive jurisdiction and venue in the federal court in King County, Washington for all disputes heard in court (excluding arbitration). If not, you and Microsoft consent to exclusive jurisdiction and venue in the Superior Court of King County, Washington for all disputes heard in court (excluding arbitration).\par
\pard\widctlpar\par
\pard\widctlpar\fi-360\li360 10.\tab ENTIRE AGREEMENT. This agreement, and any other terms Microsoft may provide for supplements, updates, or third-party applications, is the entire agreement for the software.\par
\pard\sa200\sl276\slmult1\f1\fs22\lang9\par
\pard\f2\fs17\lang2057\par
}
"@
    $richTextBox1.BackColor = [System.Drawing.Color]::White
    $btnAcknowledge.Anchor = [System.Windows.Forms.AnchorStyles]::Bottom -bor [System.Windows.Forms.AnchorStyles]::Right
    $btnAcknowledge.Location = New-Object System.Drawing.Point(544, 415)
    $btnAcknowledge.Name = "btnAcknowledge";
    $btnAcknowledge.Size = New-Object System.Drawing.Size(119, 23)
    $btnAcknowledge.TabIndex = 1
    $btnAcknowledge.Text = "Accept"
    $btnAcknowledge.UseVisualStyleBackColor = $True
    $btnAcknowledge.Add_Click({$EULA.DialogResult=[System.Windows.Forms.DialogResult]::Yes})

    $btnCancel.Anchor = [System.Windows.Forms.AnchorStyles]::Bottom -bor [System.Windows.Forms.AnchorStyles]::Right
    $btnCancel.Location = New-Object System.Drawing.Point(669, 415)
    $btnCancel.Name = "btnCancel"
    $btnCancel.Size = New-Object System.Drawing.Size(119, 23)
    $btnCancel.TabIndex = 2
    if($mode -ne 0)
    {
	    $btnCancel.Text = "Close"
    }
    else
    {
	    $btnCancel.Text = "Decline"
    }
    $btnCancel.UseVisualStyleBackColor = $True
    $btnCancel.Add_Click({$EULA.DialogResult=[System.Windows.Forms.DialogResult]::No})

    $EULA.AutoScaleDimensions = New-Object System.Drawing.SizeF(6.0, 13.0)
    $EULA.AutoScaleMode = [System.Windows.Forms.AutoScaleMode]::Font
    $EULA.ClientSize = New-Object System.Drawing.Size(800, 450)
    $EULA.Controls.Add($btnCancel)
    $EULA.Controls.Add($richTextBox1)
    if($mode -ne 0)
    {
	    $EULA.AcceptButton=$btnCancel
    }
    else
    {
        $EULA.Controls.Add($btnAcknowledge)
	    $EULA.AcceptButton=$btnAcknowledge
        $EULA.CancelButton=$btnCancel
    }
    $EULA.ResumeLayout($false)
    $EULA.Size = New-Object System.Drawing.Size(800, 650)

    Return ($EULA.ShowDialog())
}

function ShowEULAIfNeeded($toolName, $mode)
{
	$eulaRegPath = "HKCU:Software\Microsoft\CESDiagnosticTools"
	$eulaAccepted = "No"
	$eulaValue = $toolName + " EULA Accepted"
	if(Test-Path $eulaRegPath)
	{
		$eulaRegKey = Get-Item $eulaRegPath
		$eulaAccepted = $eulaRegKey.GetValue($eulaValue, "No")
	}
	else
	{
		$eulaRegKey = New-Item $eulaRegPath
	}
	if($mode -eq 2) # silent accept
	{
		$eulaAccepted = "Yes"
       		$ignore = New-ItemProperty -Path $eulaRegPath -Name $eulaValue -Value $eulaAccepted -PropertyType String -Force
	}
	else
	{
		if($eulaAccepted -eq "No")
		{
			$eulaAccepted = ShowEULAPopup($mode)
			if($eulaAccepted -eq [System.Windows.Forms.DialogResult]::Yes)
			{
	        		$eulaAccepted = "Yes"
	        		$ignore = New-ItemProperty -Path $eulaRegPath -Name $eulaValue -Value $eulaAccepted -PropertyType String -Force
			}
		}
	}
	return $eulaAccepted
}

Function UEXRDS_LogMessage {
    param( [ValidateNotNullOrEmpty()][int] $Level, [ValidateNotNullOrEmpty()][string] $Message, [ValidateNotNullOrEmpty()][string] $Color)

    If (!$Level) { $Level = $LogLevel.Normal }

    $LogMessage = (get-date).ToString("yyyyMMdd HH:mm:ss.fff") + " " + $Message

    Switch($Level){
        '0'{ # Normal + console
            $MessageColor = 'White'
            $LogConsole = $True
        }
        '1'{ # Info + console
            $MessageColor = 'Yellow'
            $LogConsole = $True
        }
        '2'{ # Warning + console
            $MessageColor = 'Magenta'
            $LogConsole = $True
        }
        '3'{ # Error
            $MessageColor = 'Red'
            $LogConsole = $False
        }
        '4'{ # ErrorLogFileOnly
            $LogConsole = $False
        }
        '5'{ # WarnLogFileOnly
            $LogConsole = $False
        }
    }

    If (($Color) -and $Color.Length -ne 0) { $MessageColor = $Color }

    $Index = 0
    # In case of Warning/Error/Debug, add line and function name to message.
    If($Level -eq $LogLevel.Warning -or $Level -eq $LogLevel.Error -or $Level -eq $LogLevel.Debug -or $Level -eq $LogLevel.ErrorLogFileOnly -or $Level -eq $LogLevel.WarnLogFileOnly){
        $CallStack = Get-PSCallStack
        $CallerInfo = $CallStack[$Index]

        If($CallerInfo.FunctionName -like "*UEXRDS_LogMessage"){
            $CallerInfo = $CallStack[$Index+1]
        }

        If($CallerInfo.FunctionName -like "*UEXRDS_LogException"){
            $CallerInfo = $CallStack[$Index+2]
        }

        $FuncName = $CallerInfo.FunctionName
        If($FuncName -eq "<ScriptBlock>"){
            $FuncName = "Main"
        }
        $LogMessage = ((Get-Date).ToString("yyyyMMdd HH:mm:ss.fff") + ': [' + $FuncName + '(' + $CallerInfo.ScriptLineNumber + ')] ' + $Message)
    }Else{
        $LogMessage = (Get-Date).ToString("yyyyMMdd HH:mm:ss.fff") + " " + $Message
    }

    # In case of Error, log to error file
    If($Level -eq $LogLevel.Error -or $Level -eq $LogLevel.ErrorLogFileOnly){
        If(!(Test-Path -Path $LogDir)){
            UEXRDS_CreateLogFolder $LogDir
        }
        $LogMessage | Out-File -Append $ErrorLogFile
    }

    If($LogConsole){
        Write-Host $LogMessage -ForegroundColor $MessageColor
        $LogMessage | Out-File -Append $OutputLogFile
    }

    if ($Level -eq $LogLevel.WarnLogFileOnly) {
        $LogMessage | Out-File -Append $OutputLogFile
    }

}

Function UEXRDS_LogDiag {
    param( [ValidateNotNullOrEmpty()][int] $Level, [ValidateNotNullOrEmpty()][string] $Message, [string] $Color, [string] $NoTimeStamp)

    If (!$Level) { $Level = $LogLevel.Normal }

    if ($NoTimeStamp) { $DiagMessage = $Message } else { $DiagMessage = (get-date).ToString("yyyyMMdd HH:mm:ss.fff") + " " + $Message }

    Switch($Level){
        '0'{ # Normal
            $MessageColor = 'Yellow'
            $LogConsole = $True
        }
        '2'{ # Warning
            $MessageColor = 'Magenta'
            $LogConsole = $True
        }
        '3'{ # Error
            $MessageColor = 'Red'
            $LogConsole = $True
        }
        '7'{ # Info only
            $LogConsole = $False
        }
    }

    If ((!$Color) -and $Color.Length -ne 0) { $MessageColor = $Color }

    If (!(Test-Path -Path $LogDir)) { UEXRDS_CreateLogFolder $LogDir }

    If($LogConsole){
        Write-Host $DiagMessage -ForegroundColor $MessageColor
        $DiagMessage | Out-File -Append $DiagFile
    } else {
        $DiagMessage | Out-File -Append $DiagFile
    }
}

Function UEXRDS_CreateLogFolder {
    Param([Parameter(Mandatory=$True)][ValidateNotNullOrEmpty()][string]$LogFolder)

    If(!(test-path -Path $LogFolder)){
        Try {
            Write-Host ((get-date).ToString("yyyyMMdd HH:mm:ss.fff") + " Creating log folder $LogFolder") -ForegroundColor Yellow
            (get-date).ToString("yyyyMMdd HH:mm:ss.fff") + " Creating log folder $LogFolder" | Out-File -Append $OutputLogFile
            New-Item $LogFolder -ItemType Directory -ErrorAction Stop | Out-Null
        } Catch {
            UEXRDS_LogException "ERROR: An error occurred while creating $LogFolder" -ErrObj $_ $fLogFileOnly
        }
    } Else {
        UEXRDS_LogMessage "$LogFolder already exist."
    }
}

Function UEXRDS_CleanUpandExit{
    If (($Null -ne $TempCommandErrorFile) -and (Test-Path -Path $TempCommandErrorFile)) { Remove-Item $TempCommandErrorFile -Force | Out-Null }
    If ($fQuickEditCodeExist) { [DisableConsoleQuickEdit]::SetQuickEdit($False) | Out-Null }
    Exit
}

Function UEXRDS_LogException{
    param([parameter(Mandatory=$true)][ValidateNotNullOrEmpty()][String]$Message, [parameter(Mandatory=$true)][ValidateNotNullOrEmpty()][System.Management.Automation.ErrorRecord]$ErrObj, [Bool]$fErrorLogFileOnly)

    $ErrorCode = "0x" + [Convert]::ToString($ErrObj.Exception.HResult,16)
    $ExternalException = [System.ComponentModel.Win32Exception]$ErrObj.Exception.HResult
    $ErrorMessage = $Message + "`n" `
        + "Command/Function: " + $ErrObj.CategoryInfo.Activity + " failed with $ErrorCode => " + $ExternalException.Message + "`n" `
        + $ErrObj.CategoryInfo.Reason + ": " + $ErrObj.Exception.Message + "`n" `
        + "ScriptStack:" + "`n" `
        + $ErrObj.ScriptStackTrace
    If($fErrorLogFileOnly){
        UEXRDS_LogMessage $LogLevel.ErrorLogFileOnly $ErrorMessage
    } Else {
        UEXRDS_LogMessage $LogLevel.Error $ErrorMessage
    }
}

Function UEXRDS_RunCommands{
    param(
        [parameter(Mandatory=$true)][ValidateNotNullOrEmpty()][String]$LogPrefix, [parameter(Mandatory=$true)][ValidateNotNullOrEmpty()][String[]]$CmdletArray, [parameter(Mandatory=$true)][Bool]$ThrowException,
        [parameter(Mandatory=$true)][Bool]$ShowMessage, [Bool]$ShowError=$False
    )

    ForEach($CommandLine in $CmdletArray){
        $tmpMsg = $CommandLine -replace "\| Out-File.*$",""
        $tmpMsg = $tmpMsg -replace "\| Out-Null.*$",""
        $tmpMsg = $tmpMsg -replace "\-ErrorAction Stop",""
        $tmpMsg = $tmpMsg -replace "\-ErrorAction SilentlyContinue",""
        $CmdlineForDisplayMessage = $tmpMsg -replace "2>&1",""
        Try{
            If ($ShowMessage) { UEXRDS_LogMessage $LogLevel.Normal ("[$LogPrefix] Running $CmdlineForDisplayMessage") }

            # There are some cases where Invoke-Expression does not reset $LASTEXITCODE and $LASTEXITCODE has old error value. Hence initialize the powershell managed value manually...
            $LASTEXITCODE = 0

            # Run actual command here. Redirect all streams to temporary error file as some commands output an error to warning stream(3) and others are to error stream(2).
            Invoke-Expression -Command $CommandLine -ErrorAction Stop *> $TempCommandErrorFile

            # It is possible $LASTEXITCODE becomes null in some sucessful case, so perform null check and examine error code.
            If($LASTEXITCODE -ne $Null -and $LASTEXITCODE -ne 0){
                $Message = "An error happened during running `'$CommandLine` " + '(Error=0x' + [Convert]::ToString($LASTEXITCODE,16) + ')'
                UEXRDS_LogMessage $LogLevel.ErrorLogFileOnly $Message
                If(Test-Path -Path $TempCommandErrorFile){
                    # Always log error to error file.
                    Get-Content $TempCommandErrorFile -ErrorAction SilentlyContinue | Out-File -Append $ErrorLogFile
                    # If -ShowError:$True, show the error to console.
                    If($ShowError){
                        Write-Host ("Error happened in $CommandLine.") -ForegroundColor Red
                        Write-Host ('---------- ERROR MESSAGE ----------')
                        Get-Content $TempCommandErrorFile -ErrorAction SilentlyContinue
                        Write-Host ('-----------------------------------')
                    }
                }
                Remove-Item $TempCommandErrorFile -Force -ErrorAction SilentlyContinue | Out-Null
                If($ThrowException){
                    Throw($Message)
                }
            } Else {
                Remove-Item $TempCommandErrorFile -Force -ErrorAction SilentlyContinue | Out-Null
            }

        }Catch{
            If($ThrowException){
                Throw $_   # Leave the error handling to upper function.
            }Else{
                $Message = "An error happened in Invoke-Expression with $CommandLine"
                UEXRDS_LogException ($Message) -ErrObj $_ $fLogFileOnly
                If ($ShowError){
                    Write-Host ("ERROR: $Message") -ForegroundColor Red
                    Write-Host ('---------- ERROR MESSAGE ----------')
                    $_
                    Write-Host ('-----------------------------------')
                }
                Continue
            }
        }
    }
}

Function UEXRDS_GetRegKeys {
    Param([Parameter(Mandatory=$True)][ValidateNotNullOrEmpty()][string]$RegRoot, [Parameter(Mandatory=$True)][ValidateNotNullOrEmpty()][string]$RegPath, [Parameter(Mandatory=$True)][ValidateNotNullOrEmpty()][string]$RegFile)

    $RegOut = $RegLogFolder + $env:computername + "_reg_" + $RegFile
    $RegFullPath = $RegRoot + "\" + $RegPath
    $RegTest = $RegRoot + ":\" + $RegPath

    if (Test-path $RegTest) {
        Try{
            reg export $RegFullPath $RegOut | Out-Null
        } Catch {
            UEXRDS_LogException ("Error: An exception occurred in UEXRDS_GetRegKeys $RegFullPath.") -ErrObj $_ $fLogFileOnly
            Continue
        }
    } else {
        UEXRDS_LogMessage $LogLevel.WarnLogFileOnly "[$LogPrefix] Registry Key '$RegFullPath' not found."
        Continue
    }
}

Function UEXRDS_GetEventLogs {
    Param([Parameter(Mandatory=$True)][ValidateNotNullOrEmpty()][string]$EventSource, [Parameter(Mandatory=$True)][ValidateNotNullOrEmpty()][string]$EventFile)

    $EventOut = $EventLogFolder + $env:computername + "_evt_" + $EventFile
    $CommandLine = "wevtutil epl '$EventSource' $EventOut 2>&1 | Out-Null"

    if (Get-WinEvent -ListLog $EventSource -ErrorAction SilentlyContinue) {
        Try {
            Invoke-Expression $CommandLine
        } Catch {
            UEXRDS_LogException ("Error: An error occurred in $CommandLine") -ErrObj $_ $fLogFileOnly
            Continue
        }
    } else {
        UEXRDS_LogMessage $LogLevel.WarnLogFileOnly "[$LogPrefix] Event log '$EventSource' not found."
    }
}

Function UEXRDS_GetWinRMConfig {
    $winrmfile = $SysInfoLogFolder + $LogFilePrefix + "WinRM-Config.txt"

    if ((get-service -name WinRM).status -eq "Running") {
        Try {
            $config = Get-ChildItem WSMan:\localhost\ -Recurse -ErrorAction Continue 2>&1 | Out-Null
            if (!$config) {
                UEXRDS_LogMessage $LogLevel.WarnLogFileOnly ("[$LogPrefix] Cannot connect to localhost, trying with FQDN " + $fqdn)
                Connect-WSMan -ComputerName $fqdn -ErrorAction Continue 2>&1 | Out-Null
                $config = Get-ChildItem WSMan:\$fqdn -Recurse -ErrorAction Continue 2>&1 | Out-Null
                Disconnect-WSMan -ComputerName $fqdn -ErrorAction Continue 2>&1 | Out-Null
            }
            $config | out-file -Append $winrmfile
        } Catch {
            UEXRDS_LogException ("ERROR: An error occurred during getting WinRM configuration") -ErrObj $_ $fLogFileOnly
            Continue
        }

        winrm get winrm/config 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFilePrefix + "WinRM-Config.txt")
        winrm e winrm/config/listener 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFilePrefix + "WinRM-Config.txt")

    } else {
        UEXRDS_LogMessage $LogLevel.Error ("[$LogPrefix] WinRM service is not running. Skipping collection of WinRM configuration data.")
    }
}

Function UEXRDS_GetFSLogixLogFiles {
    Param([Parameter(Mandatory=$True)][ValidateNotNullOrEmpty()][string]$LogFilePath)

    if (Test-path -path "$LogFilePath") {
        Copy-Item $LogFilePath $FSLogixLogFolder -Recurse -ErrorAction Continue 2>&1 | Out-Null
    } else {
        UEXRDS_LogMessage $LogLevel.WarnLogFileOnly "[$LogPrefix] '$LogFilePath' folder not found."
    }
}

Function UEXRDS_GetStore($store) {
    $certlist = Get-ChildItem ("Cert:\LocalMachine\" + $store)

    foreach ($cert in $certlist) {
        $EKU = ""
        foreach ($item in $cert.EnhancedKeyUsageList) {
            if ($item.FriendlyName) {
                $EKU += $item.FriendlyName + " / "
            } else {
                $EKU += $item.ObjectId + " / "
            }
        }

        $row = $tbcert.NewRow()

        foreach ($ext in $cert.Extensions) {
            if ($ext.oid.value -eq "2.5.29.14") {
                $row.SubjectKeyIdentifier = $ext.SubjectKeyIdentifier.ToLower()
            }
            if (($ext.oid.value -eq "2.5.29.35") -or ($ext.oid.value -eq "2.5.29.1")) {
                $asn = New-Object Security.Cryptography.AsnEncodedData ($ext.oid,$ext.RawData)
                $aki = $asn.Format($true).ToString().Replace(" ","")
                $aki = (($aki -split '\n')[0]).Replace("KeyID=","").Trim()
                $row.AuthorityKeyIdentifier = $aki
            }
        }

        if ($EKU) {$EKU = $eku.Substring(0, $eku.Length-3)}
        $row.Store = $store
        $row.Thumbprint = $cert.Thumbprint.ToLower()
        $row.Subject = $cert.Subject
        $row.Issuer = $cert.Issuer
        $row.NotAfter = $cert.NotAfter
        $row.EnhancedKeyUsage = $EKU
        $row.SerialNumber = $cert.SerialNumber.ToLower()
        $tbcert.Rows.Add($row)
    }
}


Add-Type -MemberDefinition @"
[DllImport("netapi32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
public static extern uint NetApiBufferFree(IntPtr Buffer);
[DllImport("netapi32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
public static extern int NetGetJoinInformation(
    string server,
    out IntPtr NameBuffer,
    out int BufferType);
"@ -Namespace Win32Api -Name NetApi32

Function UEXRDS_GetNBDomainName {
    $pNameBuffer = [IntPtr]::Zero
    $joinStatus = 0
    $apiResult = [Win32Api.NetApi32]::NetGetJoinInformation(
        $null,               # lpServer
        [Ref] $pNameBuffer,  # lpNameBuffer
        [Ref] $joinStatus    # BufferType
    )
    if ( $apiResult -eq 0 ) {
        [Runtime.InteropServices.Marshal]::PtrToStringAuto($pNameBuffer)
        [Void] [Win32Api.NetApi32]::NetApiBufferFree($pNameBuffer)
    }
}

Function UEXRDS_FileVersion {
    param(
        [string] $FilePath, [bool] $Log = $false
    )

    if (Test-Path -Path $FilePath) {
        $fileobj = Get-item $FilePath
        $filever = $fileobj.VersionInfo.FileMajorPart.ToString() + "." + $fileobj.VersionInfo.FileMinorPart.ToString() + "." + $fileobj.VersionInfo.FileBuildPart.ToString() + "." + $fileobj.VersionInfo.FilePrivatepart.ToString()

        if ($log) {
            ($FilePath + "," + $filever + "," + $fileobj.CreationTime.ToString("yyyyMMdd HH:mm:ss")) 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFilePrefix + "ver_KeyFileVersions.csv")
        }
        return $filever | Out-Null
    } else {
        return ""
    }
}

function UEXRDS_GetRDRoleInfo {
    param ($Class, $Namespace, $ComputerName = "localhost", $Auth = "PacketPrivacy", $Impersonation = "Impersonate")

    Get-WmiObject -Class $Class -Namespace $Namespace -ComputerName $ComputerName -Authentication $Auth -Impersonation $Impersonation

}

function UEXRDS_GetRDLSDB {

    $RDSLSKP = UEXRDS_GetRDRoleInfo Win32_TSLicenseKeyPack "root\cimv2"
    if ($RDSLSKP -ne $null)
    {
        $KPtitle = "Installed RDS license packs"
        $RDSLSKP | ConvertTo-Html -Title $KPtitle -body $bodyRDLS -Property PSComputerName, ProductVersion, Description, TypeAndModel, TotalLicenses, AvailableLicenses, IssuedLicenses, KeyPackId, KeyPackType, ProductVersionId, AccessRights, ExpirationDate | Out-File -Append ($RDSLogFolder + $LogFilePrefix + "rdls_LicenseKeyPacks.html")
    } else {
        UEXRDS_LogMessage $LogLevel.WarnLogFileOnly "[$LogPrefix] [WARNING] Failed to get Win32_TSLicenseKeyPack."
    }

    $RDSLSIL = UEXRDS_GetRDRoleInfo Win32_TSIssuedLicense "root\cimv2"
    if ($RDSLSIL -ne $null)
    {
        $KPtitle = "Issued RDS licenses"
        $RDSLSIL | ConvertTo-Html -Title $KPtitle -body $bodyRDLS -Property PSComputerName, LicenseId, sIssuedToUser, sIssuedToComputer, IssueDate, ExpirationDate, LicenseStatus, KeyPackId, sHardwareId | Out-File -Append ($RDSLogFolder + $LogFilePrefix + "rdls_IssuedLicenses.html")
    } else {
        UEXRDS_LogMessage $LogLevel.WarnLogFileOnly "[$LogPrefix] [WARNING] Failed to get Win32_TSIssuedLicense."
    }
}

function UEXRDS_GetRDGW {

    $RDSGWLB = UEXRDS_GetRDRoleInfo Win32_TSGatewayLoadBalancer root\cimv2\TerminalServices
    if ($RDSGWLB -ne $null)
    { $RDSGWLB | Out-File -Append ($RDSLogFolder + $LogFilePrefix + "rdgw_LoadBalancer.txt") } 
    else { UEXRDS_LogMessage $LogLevel.WarnLogFileOnly "[$LogPrefix] [WARNING] Failed to get Win32_TSGatewayLoadBalancer." }

    $RDSGWRAD = UEXRDS_GetRDRoleInfo Win32_TSGatewayRADIUSServer root\cimv2\TerminalServices
    if ($RDSGWRAD -ne $null)
    { $RDSGWRAD | Out-File -Append ($RDSLogFolder + $LogFilePrefix + "rdgw_RADIUSServer.txt") }
    else { UEXRDS_LogMessage $LogLevel.WarnLogFileOnly "[$LogPrefix] [WARNING] Failed to get Win32_TSGatewayRADIUSServer." }

    $RDSGWRAP = UEXRDS_GetRDRoleInfo Win32_TSGatewayResourceAuthorizationPolicy root\cimv2\TerminalServices
    if ($RDSGWRAP -ne $null)
    { $RDSGWRAP | Out-File -Append ($RDSLogFolder + $LogFilePrefix + "rdgw_ResourceAuthorizationPolicy.txt") }
    else { UEXRDS_LogMessage $LogLevel.WarnLogFileOnly "[$LogPrefix] [WARNING] Failed to get Win32_TSGatewayResourceAuthorizationPolicy." }

    $RDSGWCAP = UEXRDS_GetRDRoleInfo Win32_TSGatewayConnectionAuthorizationPolicy root\cimv2\TerminalServices
    if ($RDSGWCAP -ne $null)
    { $RDSGWCAP | Out-File -Append ($RDSLogFolder + $LogFilePrefix + "rdgw_ConnectionAuthorizationPolicy.txt") }
    else { UEXRDS_LogMessage $LogLevel.WarnLogFileOnly "[$LogPrefix] [WARNING] Failed to get Win32_TSGatewayConnectionAuthorizationPolicy." }

    $RDSGWRG = UEXRDS_GetRDRoleInfo Win32_TSGatewayResourceGroup root\cimv2\TerminalServices
    if ($RDSGWRG -ne $null)
    { $RDSGWRG | Out-File -Append ($RDSLogFolder + $LogFilePrefix + "rdgw_ResourceGroup.txt") }
    else { UEXRDS_LogMessage $LogLevel.WarnLogFileOnly "[$LogPrefix] [WARNING] Failed to get Win32_TSGatewayResourceGroup." }

    $RDSGWS = UEXRDS_GetRDRoleInfo Win32_TSGatewayServerSettings root\cimv2\TerminalServices
    if ($RDSGWS -ne $null)
    { $RDSGWS | Out-File -Append ($RDSLogFolder + $LogFilePrefix + "rdgw_ServerSettings.txt") }
    else { UEXRDS_LogMessage $LogLevel.WarnLogFileOnly "[$LogPrefix] [WARNING] Failed to get Win32_TSGatewayServerSettings." }
}

function UEXRDS_GetRDCB {

    $RDCBW = UEXRDS_GetRDRoleInfo Win32_Workspace root\cimv2\TerminalServices
    if ($RDCBW -ne $null)
    { $RDCBW | Out-File -Append ($RDSLogFolder + $LogFilePrefix + "rdcb_Workspace.txt") } 
    else { UEXRDS_LogMessage $LogLevel.WarnLogFileOnly "[$LogPrefix] [WARNING] Failed to get Win32_Workspace." }

    $RDCBCPF = UEXRDS_GetRDRoleInfo Win32_RDCentralPublishedFarm root\cimv2\TerminalServices
    if ($RDCBCPF -ne $null)
    { $RDCBCPF | Out-File -Append ($RDSLogFolder + $LogFilePrefix + "rdcb_CentralPublishedFarm.txt") }
    else { UEXRDS_LogMessage $LogLevel.WarnLogFileOnly "[$LogPrefix] [WARNING] Failed to get Win32_RDCentralPublishedFarm." }

    $RDCBCPDS = UEXRDS_GetRDRoleInfo Win32_RDCentralPublishedDeploymentSettings root\cimv2\TerminalServices
    if ($RDCBCPDS -ne $null)
    { $RDCBCPDS | Out-File -Append ($RDSLogFolder + $LogFilePrefix + "rdcb_CentralPublishedDeploymentSettings.txt") }
    else { UEXRDS_LogMessage $LogLevel.WarnLogFileOnly "[$LogPrefix] [WARNING] Failed to get Win32_RDCentralPublishedDeploymentSettings." }

    $RDCBCPFA = UEXRDS_GetRDRoleInfo Win32_RDCentralPublishedFileAssociation root\cimv2\TerminalServices
    if ($RDCBCPFA -ne $null)
    { $RDCBCPFA | Out-File -Append ($RDSLogFolder + $LogFilePrefix + "rdcb_CentralPublishedFileAssociation.txt") }
    else { UEXRDS_LogMessage $LogLevel.WarnLogFileOnly "[$LogPrefix] [WARNING] Failed to get Win32_RDCentralPublishedFileAssociation." }

    $RDCBPDA = UEXRDS_GetRDRoleInfo Win32_RDPersonalDesktopAssignment root\cimv2\TerminalServices
    if ($RDCBPDA -ne $null)
    { $RDCBPDA | Out-File -Append ($RDSLogFolder + $LogFilePrefix + "rdcb_PersonalDesktopAssignment.txt") }
    else { UEXRDS_LogMessage $LogLevel.WarnLogFileOnly "[$LogPrefix] [WARNING] Failed to get Win32_RDPersonalDesktopAssignment." }

    $RDCBSDC = UEXRDS_GetRDRoleInfo Win32_SessionDirectoryCluster root\cimv2
    if ($RDCBSDC -ne $null)
    { $RDCBSDC | Out-File -Append ($RDSLogFolder + $LogFilePrefix + "rdcb_SessionDirectoryCluster.txt") }
    else { UEXRDS_LogMessage $LogLevel.WarnLogFileOnly "[$LogPrefix] [WARNING] Failed to get Win32_SessionDirectoryCluster." }

    $RDCBDS = UEXRDS_GetRDRoleInfo Win32_RDMSDeploymentSettings root\cimv2\rdms
    if ($RDCBDS -ne $null)
    { $RDCBDS | Out-File -Append ($RDSLogFolder + $LogFilePrefix + "rdcb_RDMSDeploymentSettings.txt") }
    else { UEXRDS_LogMessage $LogLevel.WarnLogFileOnly "[$LogPrefix] [WARNING] Failed to get Win32_RDMSDeploymentSettings." }
}

function UEXRDS_GetRDWA {

    $IISConfig = (C:\WINDOWS\SYSTEM32\INETSRV\APPCMD list config)
    if ($IISConfig -ne $null) {
        $IISConfig | Out-File -Append ($RDSLogFolder + $LogFilePrefix + "rdwa_IISConfig.txt")
    }
}


#endregion Internal functions


#region Diag functions

function UEXRDS_TestRegistryValue {
    param ([parameter(Mandatory=$true)][ValidateNotNullOrEmpty()]$Path, [parameter(Mandatory=$true)][ValidateNotNullOrEmpty()]$Value)

    try {
        $trv = Get-ItemProperty -Path $Path -ErrorAction Stop | Select-Object -ExpandProperty $Value -ErrorAction Stop
        if ($trv -or ($trv -eq 0)) {
            return $true
        } else {
            return $false
        }
    }
    catch {
        return $false
    }
}

Function UEXRDS_DiagIssues {
    Param([Parameter(Mandatory=$True)][ValidateNotNullOrEmpty()][string]$IssueType, [Parameter(Mandatory=$True)][ValidateNotNullOrEmpty()][string]$LogName, [Parameter(Mandatory=$True)][ValidateNotNullOrEmpty()][string]$LogID, [Parameter(Mandatory=$True)][ValidateNotNullOrEmpty()][string]$Message)

    $StartTimeA = (Get-Date).AddDays(-5)
       
    If (Get-WinEvent -FilterHashtable @{logname=$LogName; id=$LogID; StartTime=$StartTimeA} -ErrorAction SilentlyContinue | where-object { $_.Message -like '*' + $Message + '*' }) {
        UEXRDS_LogDiag $LogLevel.DiagFileOnly "... [WARNING] One or more events $LogID with '$Message' have been found."
        If ($IssueType -eq "FSLogix") {
            $Global:FSLogixIssues = $Global:FSLogixIssues + 1
            $issuefile = "RDS-Diag-FSLogixIssuesEvents.txt"
        }        
        Get-WinEvent -FilterHashtable @{logname=$LogName; id=$LogID; StartTime=$StartTimeA} -ErrorAction SilentlyContinue | where-object { $_.Message -like '*' + $Message + '*' } | Format-List | Out-File -Append ($BasicLogFolder + $issuefile)
    }
}

Function UEXRDS_DiagProcessCrash {
    $StartTimeP = (Get-Date).AddDays(-5)

    If (!(Get-WinEvent -FilterHashtable @{logname="Application"; ProviderName='Application Error'; StartTime=$StartTimeP} -ErrorAction SilentlyContinue | where-object { $_.Message -like '*Faulting application name*' })) {
        UEXRDS_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] Process crash events not found."
    } else {
        UEXRDS_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] [WARNING] One or more process crash events have been found over the past 5 days. See 'RDS-Diag-ProcessCrashEvents.txt' for more information."
        Get-WinEvent -FilterHashtable @{logname="Application"; ProviderName='Application Error'; StartTime=$StartTimeP} -ErrorAction SilentlyContinue | Format-List | Out-File -Append ($BasicLogFolder + "RDS-Diag-ProcessCrashEvents.txt")
    }
}

Function UEXRDS_CheckRegKeyValue {
    Param([Parameter(Mandatory=$True)][ValidateNotNullOrEmpty()][string]$RegPath, [Parameter(Mandatory=$True)][ValidateNotNullOrEmpty()][string]$RegKey, [string]$RegValue, [string]$OptNote)

    $global:regok = $null

    if (UEXRDS_TestRegistryValue -path $RegPath -value $RegKey) {
        (Get-ItemProperty -path $RegPath).PSChildName | foreach-object -process {
            $key = Get-ItemPropertyValue -Path $RegPath -name $RegKey
            if ($RegValue) {
                if ($key -eq $RegValue) {
                    $global:regok = 1
                    UEXRDS_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] Registry key '$RegPath$RegKey' exists and has the expected value of: " + $key  + ". " + $OptNote)
                }
                else {
                    $global:regok = 2
                    UEXRDS_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] [WARNING] Registry key '$RegPath$RegKey' exists and has a value of '" + $key + "' but this is not the expected value. (The expected value is: " + $RegValue + "). " + $OptNote)
                }
            } else {
                UEXRDS_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] Registry key '$RegPath$RegKey' exists and has a value of: " + $key + ". " + $OptNote)
            }
        }
    } else {
        $global:regok = 0
        UEXRDS_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] Registry key '$RegPath$RegKey' not found. " + $OptNote)
    }
}

Function UEXRDS_TestAVExclusion {
    Param([Parameter(Mandatory=$True)][ValidateNotNullOrEmpty()][string]$ExclPath, [Parameter(Mandatory=$True)][ValidateNotNullOrEmpty()][array]$ExclValue)

    if (Test-Path $ExclPath) {
        if ((Get-Item $ExclPath).Property) {
            $msgpath = Compare-Object -ReferenceObject(@((Get-Item $ExclPath).Property)) -DifferenceObject(@($ExclValue))

            UEXRDS_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] Comparing local values found with recommended values. False positives may occur if you use full paths instead of environment variables."
            if ($msgpath) {
                UEXRDS_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] [WARNING] '=>' indicates a recommended value that is not configured on this VM."
                UEXRDS_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] [WARNING] '<=' indicates a configured value that is not part of the list of recommended values."
                $msgpath | Out-File -FilePath $diagfile -Append
            } else {
                UEXRDS_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] No differences found."
            }

        } else {
            UEXRDS_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] [WARNING] No Paths exclusions have been found. Follow the above article to configure the recommended exclusions."
        }

    } else {
        UEXRDS_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] '$ExclPath' not found. You should have the recommendations implemented either locally (UI/PowerShell) or through GPO."
    }
}

#endregion Diag functions


#region Main functions

Function CollectUEX_RDSCoreLog{
    " " | Out-File -Append $OutputLogFile
    UEXRDS_LogMessage $LogLevel.Info "Running data collection - please wait ...`n" -Color "Cyan"

    #Collecting RDS information
    " " | Out-File -Append $OutputLogFile
    UEXRDS_LogMessage $LogLevel.Info ('Collecting RDS information')
    Try {
        UEXRDS_CreateLogFolder $NetLogFolder
        UEXRDS_CreateLogFolder $SysInfoLogFolder
    } Catch {
        UEXRDS_LogMessage $LogLevel.Error ("Unable to create log folder." + $_.Exception.Message)
        Return
    }
    $LogPrefix = "RDS"

    $Commands = @(
        "qwinsta /counter 2>&1 | Out-File -Append " + $NetLogFolder + $LogFilePrefix + "qwinsta.txt"
        "dxdiag /whql:off /t " + $SysInfoLogFolder + $LogFilePrefix + "DxDiag.txt"
    )
    UEXRDS_RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$True -ShowError:$True

    if ([ADSI]::Exists("WinNT://localhost/Remote Desktop Users")) {
        $Commands = @(
            "net localgroup 'Remote Desktop Users' 2>&1 | Out-File -Append " + $SysInfoLogFolder + $LogFilePrefix + "LocalGroupsMembership.txt"
        )
        UEXRDS_RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$True -ShowError:$True
    } else {
        UEXRDS_LogMessage $LogLevel.WarnLogFileOnly "[$LogPrefix] 'Remote Desktop Users' group not found."
    }

    if ([ADSI]::Exists("WinNT://localhost/RDS Remote Access Servers")) {
        $Commands = @(
            "net localgroup 'RDS Remote Access Servers' 2>&1 | Out-File -Append " + $SysInfoLogFolder + $LogFilePrefix + "LocalGroupsMembership.txt"
        )
        UEXRDS_RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$True -ShowError:$True
    } else {
        UEXRDS_LogMessage $LogLevel.WarnLogFileOnly "[$LogPrefix] 'RDS Remote Access Servers' group not found."
    }

    if ([ADSI]::Exists("WinNT://localhost/RDS Management Servers")) {
        $Commands = @(
            "net localgroup 'RDS Management Servers' 2>&1 | Out-File -Append " + $SysInfoLogFolder + $LogFilePrefix + "LocalGroupsMembership.txt"
        )
        UEXRDS_RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$True -ShowError:$True
    } else {
        UEXRDS_LogMessage $LogLevel.WarnLogFileOnly "[$LogPrefix] 'RDS Management Servers' group not found."
    }

    if ([ADSI]::Exists("WinNT://localhost/RDS Endpoint Servers")) {
        $Commands = @(
            "net localgroup 'RDS Endpoint Servers' 2>&1 | Out-File -Append " + $SysInfoLogFolder + $LogFilePrefix + "LocalGroupsMembership.txt"
        )
        UEXRDS_RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$True -ShowError:$True
    } else {
        UEXRDS_LogMessage $LogLevel.WarnLogFileOnly "[$LogPrefix] 'RDS Endpoint Servers' group not found."
    }


    #Collecting event logs
    " " | Out-File -Append $OutputLogFile
    UEXRDS_LogMessage $LogLevel.Info ('Collecting event log information')
    Try {
        UEXRDS_CreateLogFolder $EventLogFolder
    } Catch {
        UEXRDS_LogMessage $LogLevel.Error ("Unable to create log folder." + $_.Exception.Message)
        Return
    }
    $LogPrefix = "EventLog"
    $Commands = @(
        "UEXRDS_GetEventLogs 'System' 'System.evtx'"
        "UEXRDS_GetEventLogs 'Application' 'Application.evtx'"
        "UEXRDS_GetEventLogs 'Security' 'Security.evtx'"
        "UEXRDS_GetEventLogs 'Microsoft-Windows-CAPI2/Operational' 'CAPI2-Operational.evtx'"
        "UEXRDS_GetEventLogs 'Microsoft-Windows-WinRM/Operational' 'WinRM-Operational.evtx'"
        "UEXRDS_GetEventLogs 'Microsoft-Windows-RemoteDesktopServices-RdpCoreTS/Operational' 'RemoteDesktopServicesRdpCoreTS-Operational.evtx'"
        "UEXRDS_GetEventLogs 'Microsoft-Windows-RemoteDesktopServices-RdpCoreTS/Admin' 'RemoteDesktopServicesRdpCoreTS-Admin.evtx'"
        "UEXRDS_GetEventLogs 'Microsoft-Windows-RemoteDesktopServices-RdpCoreCDV/Admin' 'RemoteDesktopServicesRdpCoreCDV-Admin.evtx'"
        "UEXRDS_GetEventLogs 'Microsoft-Windows-RemoteDesktopServices-RdpCoreCDV/Operational' 'RemoteDesktopServicesRdpCoreCDV-Operational.evtx'"
        "UEXRDS_GetEventLogs 'Microsoft-Windows-TaskScheduler/Operational' 'TaskScheduler-Operational.evtx'"
        "UEXRDS_GetEventLogs 'Microsoft-Windows-TerminalServices-LocalSessionManager/Operational' 'TerminalServicesLocalSessionManager-Operational.evtx'"
        "UEXRDS_GetEventLogs 'Microsoft-Windows-TerminalServices-LocalSessionManager/Admin' 'TerminalServicesLocalSessionManager-Admin.evtx'"
        "UEXRDS_GetEventLogs 'Microsoft-Windows-TerminalServices-RemoteConnectionManager/Admin' 'TerminalServicesRemoteConnectionManager-Admin.evtx'"
        "UEXRDS_GetEventLogs 'Microsoft-Windows-TerminalServices-RemoteConnectionManager/Operational' 'TerminalServicesRemoteConnectionManager-Operational.evtx'"
        "UEXRDS_GetEventLogs 'Microsoft-Windows-TerminalServices-PnPDevices/Admin' 'TerminalServicesPnPDevices-Admin.evtx'"
        "UEXRDS_GetEventLogs 'Microsoft-Windows-TerminalServices-PnPDevices/Operational' 'TerminalServicesPnPDevices-Operational.evtx'"
        "UEXRDS_GetEventLogs 'Microsoft-Windows-WinINet-Config/ProxyConfigChanged' 'WinHttp-ProxyConfigChanged.evtx'"
        "UEXRDS_GetEventLogs 'Microsoft-Windows-Rdms-UI/Admin' 'Microsoft-Windows-Rdms-UI-Admin.evtx'"
        "UEXRDS_GetEventLogs 'Microsoft-Windows-Rdms-UI/Operational' 'Rdms-UI-Operational.evtx'"
        "UEXRDS_GetEventLogs 'Microsoft-Windows-Remote-Desktop-Management-Service/Admin' 'Remote-Desktop-Management-Service-Admin.evtx'"
        "UEXRDS_GetEventLogs 'Microsoft-Windows-Remote-Desktop-Management-Service/Operational' 'Remote-Desktop-Management-Service-Operational.evtx'"
        "UEXRDS_GetEventLogs 'Microsoft-Windows-RemoteApp and Desktop Connection Management/Admin' 'RADC-Management-Admin.evtx'"
        "UEXRDS_GetEventLogs 'Microsoft-Windows-RemoteApp and Desktop Connection Management/Operational' 'RADC-Management-Operational.evtx'"
        "UEXRDS_GetEventLogs 'Microsoft-Windows-RemoteApp and Desktop Connections/Admin' 'RADC-Admin.evtx'"
        "UEXRDS_GetEventLogs 'Microsoft-Windows-RemoteApp and Desktop Connections/Operational' 'RADC-Operational.evtx'"
        "UEXRDS_GetEventLogs 'Microsoft-Windows-TerminalServices-RDPClient/Operational' 'RDPClient-ActiveXCore.evtx'"
        "UEXRDS_GetEventLogs 'Microsoft-Windows-TerminalServices-ClientUSBDevices/Admin' 'ClientUSBDevices-Admin.evtx'"
        "UEXRDS_GetEventLogs 'Microsoft-Windows-TerminalServices-ClientUSBDevices/Operational' 'ClientUSBDevices-Operational.evtx'"
        "UEXRDS_GetEventLogs 'Microsoft-Windows-TerminalServices-Gateway/Admin' 'Gateway-Admin.evtx'"
        "UEXRDS_GetEventLogs 'Microsoft-Windows-TerminalServices-Gateway/Operational' 'Gateway-Operational.evtx'"
        "UEXRDS_GetEventLogs 'Microsoft-Windows-TerminalServices-Licensing/Admin' 'Licensing-Admin.evtx'"
        "UEXRDS_GetEventLogs 'Microsoft-Windows-TerminalServices-Licensing/Operational' 'Licensing-Operational.evtx'"
        "UEXRDS_GetEventLogs 'Microsoft-Windows-TerminalServices-Printers/Admin' 'Printers-Admin.evtx'"
        "UEXRDS_GetEventLogs 'Microsoft-Windows-TerminalServices-Printers/Operational' 'Printers-Operational.evtx'"
        "UEXRDS_GetEventLogs 'Microsoft-Windows-TerminalServices-ServerUSBDevices/Admin' 'ServerUSBDevices-Admin.evtx'"
        "UEXRDS_GetEventLogs 'Microsoft-Windows-TerminalServices-ServerUSBDevices/Operational' 'ServerUSBDevices-Operational.evtx'"
        "UEXRDS_GetEventLogs 'Microsoft-Windows-TerminalServices-SessionBroker/Admin' 'SessionBroker-Admin.evtx'"
        "UEXRDS_GetEventLogs 'Microsoft-Windows-TerminalServices-SessionBroker/Operational' 'SessionBroker-Operational.evtx'"
        "UEXRDS_GetEventLogs 'Microsoft-Windows-TerminalServices-SessionBroker-Client/Admin' 'SessionBroker-Client-Admin.evtx'"
        "UEXRDS_GetEventLogs 'Microsoft-Windows-TerminalServices-SessionBroker-Client/Operational' 'SessionBroker-Client-Operational.evtx'"
        "UEXRDS_GetEventLogs 'Microsoft-Windows-TerminalServices-TSAppSrv-TSMSI/Admin' 'TSAppSrv-TSMSI-Admin.evtx'"
        "UEXRDS_GetEventLogs 'Microsoft-Windows-TerminalServices-TSAppSrv-TSMSI/Operational' 'TSAppSrv-TSMSI-Operational.evtx'"
        "UEXRDS_GetEventLogs 'Microsoft-Windows-TerminalServices-TSAppSrv-TSVIP/Admin' 'TSAppSrv-TSVIP-Admin.evtx'"
        "UEXRDS_GetEventLogs 'Microsoft-Windows-TerminalServices-TSAppSrv-TSVIP/Operational' 'TSAppSrv-TSVIP-Operational.evtx'"
    )
    UEXRDS_RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$True -ShowError:$True


    #Collecting registry keys
    " " | Out-File -Append $OutputLogFile
    UEXRDS_LogMessage $LogLevel.Info ('Collecting registry key information')
    Try {
        UEXRDS_CreateLogFolder $RegLogFolder
    } Catch {
        UEXRDS_LogMessage $LogLevel.Error ("Unable to create log folder." + $_.Exception.Message)
        Return
    }
    $LogPrefix = "Reg"
    $Commands = @(
        "UEXRDS_GetRegKeys 'HKLM' 'SOFTWARE\Microsoft\NET Framework Setup\NDP' 'SW-MS-NetFS-NDP.txt'"
        "UEXRDS_GetRegKeys 'HKLM' 'SOFTWARE\Microsoft\Terminal Server Client' 'SW-MS-TerminalServerClient.txt'"
        "UEXRDS_GetRegKeys 'HKLM' 'SOFTWARE\Microsoft\Windows\CurrentVersion\Policies' 'SW-MS-Win-CV-Policies.txt'"
        "UEXRDS_GetRegKeys 'HKLM' 'SOFTWARE\Microsoft\Windows\CurrentVersion\Run' 'SW-MS-Win-CV-Run.txt'"
        "UEXRDS_GetRegKeys 'HKLM' 'SOFTWARE\Microsoft\Windows NT\CurrentVersion\Terminal Server' 'SW-MS-WinNT-CV-TerminalServer.txt'"

        "UEXRDS_GetRegKeys 'HKLM' 'SOFTWARE\Policies\Microsoft\Cryptography' 'SW-Policies-MS-Cryptography.txt'"
        "UEXRDS_GetRegKeys 'HKLM' 'SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation' 'SW-Policies-MS-Win-CredentialsDelegation.txt'"
        "UEXRDS_GetRegKeys 'HKLM' 'SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services' 'SW-Policies-MS-WinNT-TerminalServices.txt'"

        "UEXRDS_GetRegKeys 'HKLM' 'SYSTEM\CurrentControlSet\Control\Cryptography' 'Sys-CCS-Control-Cryptography.txt'"
        "UEXRDS_GetRegKeys 'HKLM' 'SYSTEM\CurrentControlSet\Control\Lsa' 'Sys-CCS-Control-LSA.txt'"
        "UEXRDS_GetRegKeys 'HKLM' 'SYSTEM\CurrentControlSet\Control\SecurityProviders' 'Sys-CCS-Control-SecurityProviders.txt'"
        "UEXRDS_GetRegKeys 'HKLM' 'SYSTEM\CurrentControlSet\Control\Terminal Server' 'Sys-CCS-Control-TerminalServer.txt'"

        "UEXRDS_GetRegKeys 'HKLM' 'SYSTEM\CurrentControlSet\Services\TermService' 'Sys-CCS-Svc-TermService.txt'"
        "UEXRDS_GetRegKeys 'HKLM' 'SYSTEM\CurrentControlSet\Services\UmRdpService' 'Sys-CCS-Svc-UmRdpService.txt'"
        "UEXRDS_GetRegKeys 'HKLM' 'SYSTEM\CurrentControlSet\Services\WinRM' 'Sys-CCS-Svc-WinRM.txt'"

        "UEXRDS_GetRegKeys 'HKCU' 'Control Panel\International' 'HKCU-CtrlPanel-International.txt'"
        "UEXRDS_GetRegKeys 'HKCU' 'Keyboard Layout' 'HKCU-KeyboardLayout.txt'"
        "UEXRDS_GetRegKeys 'HKLM' 'SYSTEM\Keyboard Layout' 'HKLM-Sys-KeyboardLayout.txt'"
    )
    UEXRDS_RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$True -ShowError:$True


    #Collecting RDP and Net info
    " " | Out-File -Append $OutputLogFile
    UEXRDS_LogMessage $LogLevel.Info ('Collecting networking information')

    $LogPrefix = "Net"
    if (!($ver -like "*Windows 7*")) {
        $Commands = @(
            "Get-NetConnectionProfile | Out-File -Append " + $NetLogFolder + $LogFilePrefix + "NetConnectionProfile.txt"
        )
        UEXRDS_RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$True -ShowError:$True
    }

    $Commands = @(
        "netsh advfirewall firewall show rule name=all 2>&1 | Out-File -Append " + $NetLogFolder + $LogFilePrefix + "FirewallRules.txt"
        "netstat -anob 2>&1 | Out-File -Append " + $NetLogFolder + $LogFilePrefix + "Netstat.txt"
        "ipconfig /all 2>&1 | Out-File -Append " + $NetLogFolder + $LogFilePrefix + "Ipconfig.txt"
        "netsh winhttp show proxy 2>&1 | Out-File -Append " + $NetLogFolder + $LogFilePrefix + "WinHTTP-Proxy.txt"
        "nslookup wpad 2>&1 | Out-File -Append " + $NetLogFolder + $LogFilePrefix + "WinHTTP-Proxy.txt"
        "route print 2>&1 | Out-File -Append " + $NetLogFolder + $LogFilePrefix + "Route.txt"
    )
    UEXRDS_RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$True -ShowError:$True


    #Collecting system information
    " " | Out-File -Append $OutputLogFile
    UEXRDS_LogMessage $LogLevel.Info ('Collecting system information')
    $LogPrefix = "System"

    UEXRDS_LogMessage $LogLevel.Normal "[$LogPrefix] Collecting details about currently running processes"
    $proc = Get-CimInstance -Namespace "root\cimv2" -Query "select Name, CreationDate, ProcessId, ParentProcessId, WorkingSetSize, UserModeTime, KernelModeTime, ThreadCount, HandleCount, CommandLine, ExecutablePath from Win32_Process" -ErrorAction SilentlyContinue 2>>$ErrorLogFile
    if ($PSVersionTable.psversion.ToString() -ge "3.0") {
        $StartTime= @{e={$_.CreationDate.ToString("yyyyMMdd HH:mm:ss")};n="Start time"}
    } else {
        $StartTime= @{n='StartTime';e={$_.ConvertToDateTime($_.CreationDate)}}
    }

    if ($proc) {
        $proc | Sort-Object Name | Format-Table -AutoSize -property @{e={$_.ProcessId};Label="PID"}, @{e={$_.ParentProcessId};n="Parent"}, Name,
        @{N="WorkingSet";E={"{0:N0}" -f ($_.WorkingSetSize/1kb)};a="right"},
        @{e={[DateTime]::FromFileTimeUtc($_.UserModeTime).ToString("HH:mm:ss")};n="UserTime"}, @{e={[DateTime]::FromFileTimeUtc($_.KernelModeTime).ToString("HH:mm:ss")};n="KernelTime"},
        @{N="Threads";E={$_.ThreadCount}}, @{N="Handles";E={($_.HandleCount)}}, $StartTime, CommandLine | Out-String -Width 500 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFilePrefix + "RunningProcesses.txt")

        UEXRDS_LogMessage $LogLevel.Normal "[$LogPrefix] Collecting file version of running and key system binaries"
        $binlist = $proc | Group-Object -Property ExecutablePath
        foreach ($file in $binlist) {
            if ($file.Name) {
                UEXRDS_FileVersion -Filepath ($file.name) -Log $true 2>&1 | Out-Null
            }
        }

        $pad = 27
        $OS = Get-CimInstance -Namespace "root\cimv2" -Query "select Caption, CSName, OSArchitecture, BuildNumber, InstallDate, LastBootUpTime, LocalDateTime, TotalVisibleMemorySize, FreePhysicalMemory, SizeStoredInPagingFiles, FreeSpaceInPagingFiles from Win32_OperatingSystem" -ErrorAction SilentlyContinue 2>>$ErrorLogFile
        $CS = Get-CimInstance -Namespace "root\cimv2" -Query "select Model, Manufacturer, SystemType, NumberOfProcessors, NumberOfLogicalProcessors, TotalPhysicalMemory, DNSHostName, Domain, DomainRole from Win32_ComputerSystem" -ErrorAction SilentlyContinue 2>>$ErrorLogFile
        $BIOS = Get-CimInstance -Namespace "root\cimv2" -query "select BIOSVersion, Manufacturer, ReleaseDate, SMBIOSBIOSVersion from Win32_BIOS" -ErrorAction SilentlyContinue 2>>$ErrorLogFile
        $TZ = Get-CimInstance -Namespace "root\cimv2" -Query "select Description from Win32_TimeZone" -ErrorAction SilentlyContinue 2>>$ErrorLogFile
        $PR = Get-CimInstance -Namespace "root\cimv2" -Query "select Name, Caption from Win32_Processor" -ErrorAction SilentlyContinue 2>>$ErrorLogFile

        $ctr = Get-Counter -Counter "\Memory\Pool Paged Bytes" -ErrorAction SilentlyContinue 2>>$ErrorLogFile
        $PoolPaged = $ctr.CounterSamples[0].CookedValue
        $ctr = Get-Counter -Counter "\Memory\Pool Nonpaged Bytes" -ErrorAction SilentlyContinue 2>>$ErrorLogFile
        $PoolNonPaged = $ctr.CounterSamples[0].CookedValue

        "Computer name".PadRight($pad) + " : " + $OS.CSName 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFilePrefix + "SystemInfo.txt")
        "Model".PadRight($pad) + " : " + $CS.Model 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFilePrefix + "SystemInfo.txt")
        "Manufacturer".PadRight($pad) + " : " + $CS.Manufacturer 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFilePrefix + "SystemInfo.txt")
        "BIOS Version".PadRight($pad) + " : " + $BIOS.BIOSVersion 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFilePrefix + "SystemInfo.txt")
        "BIOS Manufacturer".PadRight($pad) + " : " + $BIOS.Manufacturer 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFilePrefix + "SystemInfo.txt")
        "BIOS Release date".PadRight($pad) + " : " + $BIOS.ReleaseDate 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFilePrefix + "SystemInfo.txt")
        "SMBIOS Version".PadRight($pad) + " : " + $BIOS.SMBIOSBIOSVersion 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFilePrefix + "SystemInfo.txt")
        "SystemType".PadRight($pad) + " : " + $CS.SystemType 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFilePrefix + "SystemInfo.txt")
        "Processor".PadRight($pad) + " : " + $PR.Name + " / " + $PR.Caption 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFilePrefix + "SystemInfo.txt")
        "Processors physical/logical".PadRight($pad) + " : " + $CS.NumberOfProcessors + " / " + $CS.NumberOfLogicalProcessors 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFilePrefix + "SystemInfo.txt")
        "Memory physical/visible".PadRight($pad) + " : " + ("{0:N0}" -f ($CS.TotalPhysicalMemory/1mb)) + " MB / " + ("{0:N0}" -f ($OS.TotalVisibleMemorySize/1kb)) + " MB" 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFilePrefix + "SystemInfo.txt")
        "Pool Paged / NonPaged".PadRight($pad) + " : " + ("{0:N0}" -f ($PoolPaged/1mb)) + " MB / " + ("{0:N0}" -f ($PoolNonPaged/1mb)) + " MB" 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFilePrefix + "SystemInfo.txt")
        "Free physical memory".PadRight($pad) + " : " + ("{0:N0}" -f ($OS.FreePhysicalMemory/1kb)) + " MB" 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFilePrefix + "SystemInfo.txt")
        "Paging files size / free".PadRight($pad) + " : " + ("{0:N0}" -f ($OS.SizeStoredInPagingFiles/1kb)) + " MB / " + ("{0:N0}" -f ($OS.FreeSpaceInPagingFiles/1kb)) + " MB" 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFilePrefix + "SystemInfo.txt")
        "Operating System".PadRight($pad) + " : " + $OS.Caption + " " + $OS.OSArchitecture 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFilePrefix + "SystemInfo.txt")

        [string]$WinVerBuild = (Get-ItemProperty -Path 'Registry::HKEY_LOCAL_MACHINE\Software\Microsoft\Windows NT\CurrentVersion' CurrentBuild).CurrentBuild
        [string]$WinVerRevision = (Get-ItemProperty -Path 'Registry::HKEY_LOCAL_MACHINE\Software\Microsoft\Windows NT\CurrentVersion' UBR).UBR

        if (!($ver -like "*Windows 7*")) {
            [string]$WinVerMajor = (Get-ItemProperty -Path 'Registry::HKEY_LOCAL_MACHINE\Software\Microsoft\Windows NT\CurrentVersion' CurrentMajorVersionNumber).CurrentMajorVersionNumber
            [string]$WinVerMinor = (Get-ItemProperty -Path 'Registry::HKEY_LOCAL_MACHINE\Software\Microsoft\Windows NT\CurrentVersion' CurrentMinorVersionNumber).CurrentMinorVersionNumber
            "Build Number".PadRight($pad) + " : " + $WinVerMajor + "." + $WiNVerMinor + "." + $WinVerBuild + "." + $WinVerRevision 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFilePrefix + "SystemInfo.txt")
        } else {
            "Build Number".PadRight($pad) + " : " + $WinVerBuild + "." + $WinVerRevision 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFilePrefix + "SystemInfo.txt")
        }

        "Installation type".PadRight($pad) + " : " + (Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion").InstallationType 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFilePrefix + "SystemInfo.txt")
        "Time zone".PadRight($pad) + " : " + $TZ.Description 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFilePrefix + "SystemInfo.txt")
        "Install date".PadRight($pad) + " : " + $OS.InstallDate 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFilePrefix + "SystemInfo.txt")
        "Last boot time".PadRight($pad) + " : " + $OS.LastBootUpTime 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFilePrefix + "SystemInfo.txt")
        "Local time".PadRight($pad) + " : " + $OS.LocalDateTime 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFilePrefix + "SystemInfo.txt")
        "DNS Hostname".PadRight($pad) + " : " + $CS.DNSHostName 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFilePrefix + "SystemInfo.txt")
        "DNS Domain name".PadRight($pad) + " : " + $CS.Domain 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFilePrefix + "SystemInfo.txt")
        "NetBIOS Domain name".PadRight($pad) + " : " + (UEXRDS_GetNBDomainName) 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFilePrefix + "SystemInfo.txt")
        $roles = "Standalone Workstation", "Member Workstation", "Standalone Server", "Member Server", "Backup Domain Controller", "Primary Domain Controller"
        "Domain role".PadRight($pad) + " : " + $roles[$CS.DomainRole] 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFilePrefix + "SystemInfo.txt")

        " " | Out-File -Append ($SysInfoLogFolder + $LogFilePrefix + "SystemInfo.txt")

        $drives = @()
        $drvtype = "Unknown", "No Root Directory", "Removable Disk", "Local Disk", "Network Drive", "Compact Disc", "RAM Disk"
        $Vol = Get-CimInstance -NameSpace "root\cimv2" -Query "select * from Win32_LogicalDisk" -ErrorAction SilentlyContinue 2>>$ErrorLogFile
        foreach ($disk in $vol) {
                $drv = New-Object PSCustomObject
                $drv | Add-Member -type NoteProperty -name Letter -value $disk.DeviceID
                $drv | Add-Member -type NoteProperty -name DriveType -value $drvtype[$disk.DriveType]
                $drv | Add-Member -type NoteProperty -name VolumeName -value $disk.VolumeName
                $drv | Add-Member -type NoteProperty -Name TotalMB -Value ($disk.size)
                $drv | Add-Member -type NoteProperty -Name FreeMB -value ($disk.FreeSpace)
                $drives += $drv
            }
        $drives | Format-Table -AutoSize -property Letter, DriveType, VolumeName, @{N="TotalMB";E={"{0:N0}" -f ($_.TotalMB/1MB)};a="right"}, @{N="FreeMB";E={"{0:N0}" -f ($_.FreeMB/1MB)};a="right"} 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFilePrefix + "SystemInfo.txt")
    } else {
        $proc = Get-Process | Where-Object {$_.Name -ne "Idle"}
        $proc | Format-Table -AutoSize -property id, name, @{N="WorkingSet";E={"{0:N0}" -f ($_.workingset/1kb)};a="right"},
        @{N="VM Size";E={"{0:N0}" -f ($_.VirtualMemorySize/1kb)};a="right"},
        @{N="Proc time";E={($_.TotalProcessorTime.ToString().substring(0,8))}}, @{N="Threads";E={$_.threads.count}},
        @{N="Handles";E={($_.HandleCount)}}, StartTime, Path | Out-String -Width 300 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFilePrefix + "RunningProcesses.txt")
    }

    $Commands = @(
        "gpresult /h '" + $SysInfoLogFolder + $LogFilePrefix + "Gpresult.html'" + " 2>&1 | Out-Null"
        "gpresult /r /z 2>&1 | Out-File -Append '" + $SysInfoLogFolder + $LogFilePrefix + "Gpresult-rz.txt'"
        "Get-HotFix -ErrorAction SilentlyContinue | Sort-Object -Property InstalledOn -Descending -ErrorAction SilentlyContinue 2>&1 | Out-File -Append '" + $SysInfoLogFolder + $LogFilePrefix + "Hotfixes.txt'"
        "(Get-Item -Path 'C:\Windows\System32\*.dll').VersionInfo | Format-List -Force 2>&1 | Out-File '" + $SysInfoLogFolder + $LogFilePrefix + "ver_System32_DLL.txt'"
        "(Get-Item -Path 'C:\Windows\System32\*.exe').VersionInfo | Format-List -Force 2>&1 | Out-File '" + $SysInfoLogFolder + $LogFilePrefix + "ver_System32_EXE.txt'"
        "(Get-Item -Path 'C:\Windows\System32\*.sys').VersionInfo | Format-List -Force 2>&1 | Out-File '" + $SysInfoLogFolder + $LogFilePrefix + "ver_System32_SYS.txt'"
        "(Get-Item -Path 'C:\Windows\System32\drivers\*.sys').VersionInfo | Format-List -Force 2>&1 | Out-File '" + $SysInfoLogFolder + $LogFilePrefix + "ver_Drivers.txt'"
        "msinfo32 /nfo '" + $SysInfoLogFolder + $LogFilePrefix + "msinfo32.nfo'" + " 2>&1 | Out-Null"
        "fltmc filters 2>&1 | Out-File '" + $SysInfoLogFolder + $LogFilePrefix + "Fltmc.txt'"
        "UEXRDS_GetWinRMConfig"
    )
    UEXRDS_RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$True -ShowError:$True

    UEXRDS_LogMessage $LogLevel.Normal "[$LogPrefix] Collecting PowerShell and .Net version information"
    "PowerShell Information:" 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFilePrefix + "SystemInfo.txt")
    $PSVersionTable | Format-Table Name, Value 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFilePrefix + "SystemInfo.txt")
    ".Net Framework Information:" 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFilePrefix + "SystemInfo.txt")
    Get-ChildItem 'HKLM:\SOFTWARE\Microsoft\NET Framework Setup\NDP' -Recurse | Get-ItemProperty -Name version -EA 0 | Where-Object { $_.PSChildName -Match '^(?!S)\p{L}'} | Select-Object PSChildName, version 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFilePrefix + "SystemInfo.txt")

    UEXRDS_LogMessage $LogLevel.Normal "[$LogPrefix] Collecting service details"
    $svc = Get-CimInstance -NameSpace "root\cimv2" -Query "select  ProcessId, DisplayName, StartMode,State, Name, PathName, StartName from Win32_Service" -ErrorAction SilentlyContinue
    if ($svc) {
        $svc | Sort-Object DisplayName | Format-Table -AutoSize -Property ProcessId, DisplayName, StartMode,State, Name, PathName, StartName | Out-String -Width 400 2>&1 | Out-File -Append ($SysInfoLogFolder + $LogFilePrefix + "Services.txt")
    }

    $LogPrefix = "Cert"
    UEXRDS_LogMessage $LogLevel.Info "[$LogPrefix] Collecting certificates information"
    Try {
        UEXRDS_CreateLogFolder $CertLogFolder
    } Catch {
        UEXRDS_LogMessage $LogLevel.Error ("Unable to create log folder." + $_.Exception.Message)
        Return
    }
    $Commands = @(
        "certutil -verifystore -v MY 2>&1 | Out-File -Append '" + $CertLogFolder + $LogFilePrefix + "Certificates-My.txt'"
        "certutil -verifystore -v 'Remote Desktop' 2>&1 | Out-File -Append '" + $CertLogFolder + $LogFilePrefix + "Certificates-RemoteDesktop.txt'"
    )
    UEXRDS_RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$True -ShowError:$True

    UEXRDS_LogMessage $LogLevel.Normal "[$LogPrefix] Exporting additional certificates information"
    $tbCert = New-Object system.Data.DataTable
    $col = New-Object system.Data.DataColumn Store,([string]); $tbCert.Columns.Add($col)
    $col = New-Object system.Data.DataColumn Thumbprint,([string]); $tbCert.Columns.Add($col)
    $col = New-Object system.Data.DataColumn Subject,([string]); $tbCert.Columns.Add($col)
    $col = New-Object system.Data.DataColumn Issuer,([string]); $tbCert.Columns.Add($col)
    $col = New-Object system.Data.DataColumn NotAfter,([DateTime]); $tbCert.Columns.Add($col)
    $col = New-Object system.Data.DataColumn IssuerThumbprint,([string]); $tbCert.Columns.Add($col)
    $col = New-Object system.Data.DataColumn EnhancedKeyUsage,([string]); $tbCert.Columns.Add($col)
    $col = New-Object system.Data.DataColumn SerialNumber,([string]); $tbCert.Columns.Add($col)
    $col = New-Object system.Data.DataColumn SubjectKeyIdentifier,([string]); $tbCert.Columns.Add($col)
    $col = New-Object system.Data.DataColumn AuthorityKeyIdentifier,([string]); $tbCert.Columns.Add($col)
    UEXRDS_GetStore "My"
    $aCert = $tbCert.Select("Store = 'My' ")
    foreach ($cert in $aCert) {
        $aIssuer = $tbCert.Select("SubjectKeyIdentifier = '" + ($cert.AuthorityKeyIdentifier).tostring() + "'")
        if ($aIssuer.Count -gt 0) {
        $cert.IssuerThumbprint = ($aIssuer[0].Thumbprint).ToString()
        }
    }
    $tbcert | Export-Csv ($CertLogFolder + $LogFilePrefix + "Certificates.csv") -noType -Delimiter "`t" -Append

    $tbCert = New-Object system.Data.DataTable
    $col = New-Object system.Data.DataColumn Store,([string]); $tbCert.Columns.Add($col)
    $col = New-Object system.Data.DataColumn Thumbprint,([string]); $tbCert.Columns.Add($col)
    $col = New-Object system.Data.DataColumn Subject,([string]); $tbCert.Columns.Add($col)
    $col = New-Object system.Data.DataColumn Issuer,([string]); $tbCert.Columns.Add($col)
    $col = New-Object system.Data.DataColumn NotAfter,([DateTime]); $tbCert.Columns.Add($col)
    $col = New-Object system.Data.DataColumn IssuerThumbprint,([string]); $tbCert.Columns.Add($col)
    $col = New-Object system.Data.DataColumn EnhancedKeyUsage,([string]); $tbCert.Columns.Add($col)
    $col = New-Object system.Data.DataColumn SerialNumber,([string]); $tbCert.Columns.Add($col)
    $col = New-Object system.Data.DataColumn SubjectKeyIdentifier,([string]); $tbCert.Columns.Add($col)
    $col = New-Object system.Data.DataColumn AuthorityKeyIdentifier,([string]); $tbCert.Columns.Add($col)
    UEXRDS_GetStore "Remote Desktop"
    $aCert = $tbCert.Select("Store = 'Remote Desktop' ")
    foreach ($cert in $aCert) {
        $aIssuer = $tbCert.Select("SubjectKeyIdentifier = '" + ($cert.AuthorityKeyIdentifier).tostring() + "'")
        if ($aIssuer.Count -gt 0) {
        $cert.IssuerThumbprint = ($aIssuer[0].Thumbprint).ToString()
        }
    }
    $tbcert | Export-Csv ($CertLogFolder + $LogFilePrefix + "Certificates.csv") -noType -Delimiter "`t" -Append

    $Commands = @(
        "icacls C:\ProgramData\Microsoft\Crypto\RSA\MachineKeys 2>&1 | Out-File -Append " + $SysInfoLogFolder + $LogFilePrefix + "MachineKeys.txt"
        "icacls C:\ProgramData\Microsoft\Crypto\RSA\MachineKeys\f686aace6942fb7f7ceb231212eef4a4_* 2>&1 | Out-File -Append " + $SysInfoLogFolder + $LogFilePrefix + "MachineKeys.txt"
    )
    UEXRDS_RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$True -ShowError:$True

    #Collecting RDS role information
    if ($ver -like "*Windows Server*") {

        Try {
            UEXRDS_CreateLogFolder $RDSLogFolder
        } Catch {
            UEXRDS_LogMessage $LogLevel.Error ("Unable to create log folder." + $_.Exception.Message)
            Return
        }

        #Collecting RDLS information
        $isRDLS = (Get-WindowsFeature -Name RDS-Licensing).InstallState
        if ($isRDLS -eq "Installed") {
            " " | Out-File -Append $OutputLogFile
            UEXRDS_LogMessage $LogLevel.Info ('Collecting Remote Desktop License Server information')
            $LogPrefix = "RDLS"
            UEXRDS_LogMessage $LogLevel.Normal "[$LogPrefix] Collecting RDLS database information"
            UEXRDS_GetRDLSDB
        }

        #Collecting RDGW information
        $isRDGW = (Get-WindowsFeature -Name RDS-GATEWAY).InstallState
        if ($isRDGW -eq "Installed") {
            " " | Out-File -Append $OutputLogFile
            UEXRDS_LogMessage $LogLevel.Info ('Collecting Remote Desktop Gateway information')
            $LogPrefix = "RDGW"
            UEXRDS_GetRDGW
        }

        #Collecting RDCB information
        $isRDCB = (Get-WindowsFeature -Name RDS-CONNECTION-BROKER).InstallState
        if ($isRDCB -eq "Installed") {
            " " | Out-File -Append $OutputLogFile
            UEXRDS_LogMessage $LogLevel.Info ('Collecting Remote Desktop Connection Broker information')
            $LogPrefix = "RDCB"
            UEXRDS_GetRDCB
        }

        #Collecting RDWA information
        $isRDWA = (Get-WindowsFeature -Name RDS-WEB-ACCESS).InstallState
        if ($isRDWA -eq "Installed") {
            " " | Out-File -Append $OutputLogFile
            UEXRDS_LogMessage $LogLevel.Info ('Collecting Remote Desktop Web Access information')
            $LogPrefix = "RDWA"
            UEXRDS_GetRDWA
        }
    }
}


Function CollectUEX_RDSProfilesLog{
    " " | Out-File -Append $OutputLogFile
    UEXRDS_LogMessage $LogLevel.Info ('Collecting Profiles information (incl. FSLogix if present)')

    $LogPrefix = "Profiles"
    if (Test-path -path 'C:\Program Files\FSLogix') {

        Try {
            UEXRDS_CreateLogFolder $FSLogixLogFolder
        } Catch {
            UEXRDS_LogMessage $LogLevel.Error ("Unable to create log folder." + $_.Exception.Message)
            Return
        }


        #Collecting FSLogix Logs
        $Commands = @(
            "UEXRDS_GetFSLogixLogFiles 'C:\ProgramData\FSLogix\Logs\*'"
        )
        UEXRDS_RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$True -ShowError:$True

        $cmd = "c:\program files\fslogix\apps\frx.exe"

        if (Test-path -path 'C:\Program Files\FSLogix\apps') {
            UEXRDS_LogMessage $LogLevel.Normal ("[$LogPrefix] Running frx.exe version")
            Invoke-Expression "& '$cmd' + 'version'" | Out-File -FilePath ($FSLogixLogFolder + $LogFilePrefix + 'frx-list.txt') -Append

            "`n====================================================================================`n" | Out-File -FilePath ($FSLogixLogFolder + $LogFilePrefix + 'Frx-list.txt') -Append

            UEXRDS_LogMessage $LogLevel.Normal ("[$LogPrefix] Running frx.exe list-redirects")
            Invoke-Expression "& '$cmd' + 'list-redirects'" | Out-File -FilePath ($FSLogixLogFolder + $LogFilePrefix + 'frx-list.txt') -Append

            "`n====================================================================================`n" | Out-File -FilePath ($FSLogixLogFolder + $LogFilePrefix + 'Frx-list.txt') -Append

            UEXRDS_LogMessage $LogLevel.Normal ("[$LogPrefix] Running frx.exe list-rules")
            Invoke-Expression "& '$cmd' + 'list-rules'" | Out-File -FilePath ($FSLogixLogFolder + $LogFilePrefix + 'frx-list.txt') -Append
        } else {
            UEXRDS_LogMessage $LogLevel.WarnLogFileOnly ("[$LogPrefix] 'C:\Program Files\FSLogix\apps' folder not found.")
        }

        $Commands = @(
            "UEXRDS_GetRegKeys 'HKLM' 'SOFTWARE\FSLogix' 'SW-FSLogix.txt'"
            "UEXRDS_GetRegKeys 'HKLM' 'SOFTWARE\Policies\FSLogix' 'SW-Policies-FSLogix.txt'"
        )
        UEXRDS_RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$True -ShowError:$True
    } else {
        UEXRDS_LogMessage $LogLevel.WarnLogFileOnly ("[$LogPrefix] 'C:\Program Files\FSLogix' folder not found.")
    }


    #Collecting profile registry keys
    $LogPrefix = "Reg"
    $Commands = @(
        "UEXRDS_GetRegKeys 'HKLM' 'SOFTWARE\Microsoft\Windows Defender\Exclusions' 'SW-MS-WinDef-Exclusions.txt'"
        "UEXRDS_GetRegKeys 'HKLM' 'SOFTWARE\Policies\Microsoft\Windows Defender\Exclusions\Extensions' 'SW-GPO-MS-WinDef-Excl-Extensions.txt'"
        "UEXRDS_GetRegKeys 'HKCU' 'SOFTWARE\Microsoft\Office' 'SW-MS-Office.txt'"
        "UEXRDS_GetRegKeys 'HKCU' 'Software\Policies\Microsoft\office' 'SW-Policies-MS-Office.txt'"
        "UEXRDS_GetRegKeys 'HKLM' 'SOFTWARE\Microsoft\Windows Search' 'SW-MS-WindowsSearch.txt'"
        "UEXRDS_GetRegKeys 'HKLM' 'SOFTWARE\Microsoft\Windows NT\CurrentVersion\ProfileList' 'SW-MS-WinNT-CV-ProfileList.txt'"
    )
    UEXRDS_RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$True -ShowError:$True


    #Collecting profiles event logs
    $LogPrefix = "EventLog"
    $Commands = @(
        "UEXRDS_GetEventLogs 'Microsoft-Windows-User Profile Service/Operational' 'UserProfileService-Operational.evtx'"
        "UEXRDS_GetEventLogs 'Microsoft-Windows-VHDMP-Operational' 'VHDMP-Operational.evtx'"
        "UEXRDS_GetEventLogs 'Microsoft-Windows-SMBClient/Operational' 'SMBClient-Operational.evtx'"
        "UEXRDS_GetEventLogs 'Microsoft-Windows-SMBClient/Connectivity' 'SMBClient-Connectivity.evtx'"
        "UEXRDS_GetEventLogs 'Microsoft-Windows-SMBClient/Security' 'SMBClient-Security.evtx'"
        "UEXRDS_GetEventLogs 'Microsoft-Windows-SMBServer/Operational' 'SMBServer-Operational.evtx'"
        "UEXRDS_GetEventLogs 'Microsoft-Windows-SMBServer/Connectivity' 'SMBServer-Connectivity.evtx'"
        "UEXRDS_GetEventLogs 'Microsoft-Windows-SMBServer/Security' 'SMBServer-Security.evtx'"
        "UEXRDS_GetEventLogs 'Microsoft-FSLogix-Apps/Admin' 'FSLogix-Apps-Admin.evtx'"
        "UEXRDS_GetEventLogs 'Microsoft-FSLogix-Apps/Operational' 'FSLogix-Apps-Operational.evtx'"
        "UEXRDS_GetEventLogs 'Microsoft-FSLogix-CloudCache/Admin' 'FSLogix-CloudCache-Admin.evtx'"
        "UEXRDS_GetEventLogs 'Microsoft-FSLogix-CloudCache/Operational' 'FSLogix-CloudCache-Operational.evtx'"
    )
    UEXRDS_RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$True -ShowError:$True


    #Collecting FSLogix group memberships
    if ([ADSI]::Exists("WinNT://localhost/FSLogix ODFC Exclude List")) {
        $Commands = @(
            "net localgroup 'FSLogix ODFC Exclude List' 2>&1 | Out-File -Append " + $SysInfoLogFolder + $LogFilePrefix + "LocalGroupsMembership.txt"
        )
        UEXRDS_RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$True -ShowError:$True
    } else {
        UEXRDS_LogMessage $LogLevel.WarnLogFileOnly "[$LogPrefix] 'FSLogix ODFC Exclude List' group not found."
    }

    if ([ADSI]::Exists("WinNT://localhost/FSLogix ODFC Include List")) {
        $Commands = @(
            "net localgroup 'FSLogix ODFC Include List' 2>&1 | Out-File -Append " + $SysInfoLogFolder + $LogFilePrefix + "LocalGroupsMembership.txt"
        )
        UEXRDS_RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$True -ShowError:$True
    } else {
        UEXRDS_LogMessage $LogLevel.WarnLogFileOnly "[$LogPrefix] 'FSLogix ODFC Include List' group not found."
    }

    if ([ADSI]::Exists("WinNT://localhost/FSLogix Profile Exclude List")) {
        $Commands = @(
            "net localgroup 'FSLogix Profile Exclude List' 2>&1 | Out-File -Append " + $SysInfoLogFolder + $LogFilePrefix + "LocalGroupsMembership.txt"
        )
        UEXRDS_RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$True -ShowError:$True
    } else {
        UEXRDS_LogMessage $LogLevel.WarnLogFileOnly "[$LogPrefix] 'FSLogix Profile Exclude List' group not found."
    }

    if ([ADSI]::Exists("WinNT://localhost/FSLogix Profile Include List")) {
        $Commands = @(
            "net localgroup 'FSLogix Profile Include List' 2>&1 | Out-File -Append " + $SysInfoLogFolder + $LogFilePrefix + "LocalGroupsMembership.txt"
        )
        UEXRDS_RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$True -ShowError:$True
    } else {
        UEXRDS_LogMessage $LogLevel.WarnLogFileOnly "[$LogPrefix] 'FSLogix Profile Include List' group not found."
    }
}



Function CollectUEX_RDSMSRALog{
    $LogPrefix = "MSRA"
    " " | Out-File -Append $OutputLogFile
    UEXRDS_LogMessage $LogLevel.Info ('Collecting Remote Assistance information')

    if ([ADSI]::Exists("WinNT://localhost/Offer Remote Assistance Helpers")) {
        $Commands = @(
            "net localgroup 'Offer Remote Assistance Helpers' 2>&1 | Out-File -Append " + $SysInfoLogFolder + $LogFilePrefix + "LocalGroupsMembership.txt"
        )
        UEXRDS_RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$True -ShowError:$True

        if ([ADSI]::Exists("WinNT://localhost/Distributed COM Users")) {
            $Commands = @(
                "net localgroup 'Distributed COM Users' 2>&1 | Out-File -Append " + $SysInfoLogFolder + $LogFilePrefix + "LocalGroupsMembership.txt"
            )
            UEXRDS_RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$True -ShowError:$True
        } else {
            UEXRDS_LogMessage $LogLevel.WarnLogFileOnly "[$LogPrefix] 'Distributed COM Users' group not found."
        }

    } else {
        UEXRDS_LogMessage $LogLevel.WarnLogFileOnly "[$LogPrefix] 'Offer Remote Assistance Helpers' group not found."
    }

    $Commands = @(
        "UEXRDS_GetEventLogs 'Microsoft-Windows-RemoteAssistance/Operational' 'RemoteAssistance-Operational.evtx'"
        "UEXRDS_GetEventLogs 'Microsoft-Windows-RemoteAssistance/Admin' 'RemoteAssistance-Admin.evtx'"
        "UEXRDS_GetRegKeys 'HKLM' 'SYSTEM\CurrentControlSet\Control\Remote Assistance' 'Sys-CCS-Control-MSRA.txt'"
    )
    UEXRDS_RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$True -ShowError:$True
}


Function RunUEX_RDSDiag {
    $LogPrefix = "Diag"
    ""
    " " | Out-File -Append $OutputLogFile
    if (!$DiagOnly) {
        UEXRDS_LogMessage $LogLevel.Info "Data collection complete - running diagnostics - please wait ...`n" -Color "Cyan"
    } else {
        UEXRDS_LogMessage $LogLevel.Info "Running diagnostics - please wait ...`n" -Color "Cyan"
    }
    " " | Out-File -Append $OutputLogFile

    $DiagFile = ($BasicLogFolder + "RDS-Diag.txt")

    "`nThis report is intended to help you get a better overview of the diagnosed machine, identify known issues and ease overall troubleshooting. Depending on the issue you are investigating, additional data collection and analysis may be required." | Out-File -Append $diagfile
    " " | Out-File -Append $diagfile


#region Brief deployment info
    " " | Out-File -Append $diagfile

    UEXRDS_LogDiag $LogLevel.Normal "Checking system/deployment"
    " " | Out-File -Append $diagfile

    UEXRDS_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] FQDN: " + $fqdn)
    UEXRDS_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] OS: " + $ver)

    [string]$WinVerBuild = (Get-ItemProperty -Path 'Registry::HKEY_LOCAL_MACHINE\Software\Microsoft\Windows NT\CurrentVersion' CurrentBuild).CurrentBuild
    [string]$WinVerRevision = (Get-ItemProperty -Path 'Registry::HKEY_LOCAL_MACHINE\Software\Microsoft\Windows NT\CurrentVersion' UBR).UBR
    [string]$WinVer7 = (Get-ItemProperty -Path 'Registry::HKEY_LOCAL_MACHINE\Software\Microsoft\Windows NT\CurrentVersion' CurrentVersion).CurrentVersion

    if (!($ver -like "*Windows 7*")) {
        [string]$WinVerMajor = (Get-ItemProperty -Path 'Registry::HKEY_LOCAL_MACHINE\Software\Microsoft\Windows NT\CurrentVersion' CurrentMajorVersionNumber).CurrentMajorVersionNumber
        [string]$WiNVerMinor = (Get-ItemProperty -Path 'Registry::HKEY_LOCAL_MACHINE\Software\Microsoft\Windows NT\CurrentVersion' CurrentMinorVersionNumber).CurrentMinorVersionNumber
            if ($WinVerMajor -like "*10*") {
                If ($WinVerBuild -like "*14393*") { $PatchURL = "https://support.microsoft.com/en-us/help/4000825"
                } elseif ($WinVerBuild -like "*17763*") { $PatchURL = "https://support.microsoft.com/en-us/help/4464619"
                } elseif ($WinVerBuild -like "*18363*") { $PatchURL = "https://support.microsoft.com/en-us/help/4529964"
                } elseif ($WinVerBuild -like "*19041*") { $PatchURL = "https://support.microsoft.com/en-us/help/4555932"
                } elseif ($WinVerBuild -like "*19042*") { $PatchURL = "https://support.microsoft.com/en-us/help/4581839"
                } elseif ($WinVerBuild -like "*19043*") { $PatchURL = "https://support.microsoft.com/en-us/help/5003498"
                }
                If (($WinVerBuild -like "*14393*") -or ($WinVerBuild -like "*17763*") -or ($WinVerBuild -like "*18363*") -or ($WinVerBuild -like "*19041*") -or ($WinVerBuild -like "*19042*") -or ($WinVerBuild -like "*19043*")) {
                    $PatchHistory = " - Check the Windows Update history (" + $PatchURL + ") if the latest OS update is installed. Use the last digits of the OS build number for an easy comparison."
                }
            }
        UEXRDS_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] OS Build: " + $WinVerMajor + "." + $WiNVerMinor + "." + $WinVerBuild + "." + $WinVerRevision + $PatchHistory)
    } else {
        UEXRDS_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] OS Build: " + $WinVer7 + "." + $WinVerBuild + "." + $WinVerRevision)
    }


    #check last boot up time
    $lboott = (Get-CimInstance -ClassName win32_operatingsystem).lastbootuptime
    $lboottdif = [datetime]::Now - $lboott
    $sincereboot = " (" + $lboottdif.Days + "d " + $lboottdif.Hours + "h " + $lboottdif.Minutes + "m ago)"

    if ($lboottdif.TotalHours -ge 25) {
        UEXRDS_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] [WARNING] Last boot up time: " + $lboott + $sincereboot + ". Rebooting once every day could help clean out stuck sessions and avoid potential profile load issues.")
    } else {
        UEXRDS_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] Last boot up time: " + $lboott + $sincereboot)
    }


    #checking for useful registry keys
    $Commands = @(
        "UEXRDS_CheckRegKeyValue 'HKLM:\SYSTEM\Setup\' 'OOBEInProgress' '0'"
        "UEXRDS_CheckRegKeyValue 'HKLM:\System\CurrentControlSet\Control\Terminal Server\' 'fDenyTSConnections' '0'"
        "UEXRDS_CheckRegKeyValue 'HKLM:\System\CurrentControlSet\Control\Terminal Server\' 'fSingleSessionPerUser' '1'"
        "UEXRDS_CheckRegKeyValue 'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services\' 'fQueryUserConfigFromDC'"
        "UEXRDS_CheckRegKeyValue 'HKLM:\System\CurrentControlSet\Control\Lsa\' 'LmCompatibilityLevel'"
        "UEXRDS_CheckRegKeyValue 'HKLM:\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\' 'DeleteUserAppContainersOnLogoff' '1' 'You could run into host performance/hang issues if this key is not configured. See https://support.microsoft.com/en-us/help/4490481'"
    )
    UEXRDS_RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$False -ShowError:$True

#endregion Brief deployment info


#region Checking for installed RDS roles
    "`n======================================================================`n" | Out-File -Append $diagfile

    UEXRDS_LogDiag $LogLevel.Normal "Checking for installed RDS roles"
    " " | Out-File -Append $diagfile
    
    if ($ver -like "*Windows Server*") {
        Import-Module RemoteDesktop
        $RDSRoles = (Get-WindowsFeature -Name "RDS*" | where-object { ($_.Installed -eq "True") -and ($_.Parent -eq "Remote-Desktop-Services") }).DisplayName
        if ($RDSRoles) {
            foreach ($rdrole in $RDSRoles) {
                UEXRDS_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] $rdrole role is installed")
            }
        }
    } else {
        UEXRDS_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] Installed RDS roles not found."
    }

#endregion Checking for RDS roles

#region Checking licensing configuration for RD Session Host
    "`n======================================================================`n" | Out-File -Append $diagfile

    UEXRDS_LogDiag $LogLevel.Normal "Checking licensing configuration for RD Session Host"
    " " | Out-File -Append $diagfile

    if ($ver -like "*Windows Server*") {
        $isRDSH = (Get-WindowsFeature -Name RDS-RD-Server).InstallState
        if ($isRDSH -eq "Installed") {

            $Commands = @(
                "UEXRDS_CheckRegKeyValue 'HKLM:\SYSTEM\CurrentControlSet\Services\TermService\Parameters\LicenseServers\' 'SpecifiedLicenseServers' '' '(local config)'"
                "UEXRDS_CheckRegKeyValue 'HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\RCM\Licensing Core\' 'LicensingMode' '' '(local config)'"
                "UEXRDS_CheckRegKeyValue 'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services\' 'LicenseServers' '' '(policy config)'"
                "UEXRDS_CheckRegKeyValue 'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services\' 'LicensingMode' '' '(policy config)'"
            )
            UEXRDS_RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$False -ShowError:$True
        } else {
            UEXRDS_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] RDSH role not found. Skipping check (not applicable)"
        }
    } else {
        UEXRDS_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] Windows Server OS not found. Skipping check (not applicable)"
    }

#endregion Checking for RD Licensing configuration for RD Session Host

#region Checking for GPU configuration (if not Windows 7 or Server 2012 R2)
    "`n======================================================================`n" | Out-File -Append $diagfile

    UEXRDS_LogDiag $LogLevel.Normal "Checking for graphics configuration"
    " " | Out-File -Append $diagfile

    $Commands = @(
        "UEXRDS_CheckRegKeyValue 'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services\' 'bEnumerateHWBeforeSW'"
        "UEXRDS_CheckRegKeyValue 'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services\' 'AVCHardwareEncodePreferred'"
        "UEXRDS_CheckRegKeyValue 'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services\' 'AVC444ModePreferred' '' '(policy config)'"
        "UEXRDS_CheckRegKeyValue 'HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\' 'AVC444ModePreferred' '' '(local config)'"
        "UEXRDS_CheckRegKeyValue 'HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\' 'fEnableRemoteFXAdvancedRemoteApp'"
    )
    UEXRDS_RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$False -ShowError:$True

    UEXRDS_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] Available Video Controllers:"
    $commandline = "wmic path win32_VideoController get name,driverversion"
    $out = Invoke-Expression -Command $commandline
    foreach ($outopt in $out) {
        $outopt | Out-File -Append $DiagFile
    }

#endregion Checking for GPU configuration


#region Checking status of key services
    "`n======================================================================`n" | Out-File -Append $diagfile

    UEXRDS_LogDiag $LogLevel.Normal "Checking status of key services"
    " " | Out-File -Append $diagfile

    if (!($ver -like "*Windows 7*")) {
        $servlist = "TermService", "SessionEnv", "UmRdpService", "WinRM", "AppXSvc", "AppReadiness", "frxsvc", "frxdrv", "frxccds", "msiserver"
    } else {
        $servlist = "TermService", "SessionEnv", "UmRdpService", "WinRM", "frxsvc", "frxdrv", "frxccds", "msiserver"
    }

    $servlist | ForEach-Object -Process {

        $service = Get-Service -Name $_ -ErrorAction SilentlyContinue
        if ($service.Length -gt 0) {
            $servstatus = (Get-Service $_).Status
            $servdispname = (Get-Service $_).DisplayName
            $servstart = (Get-Service $_).StartType
            if ($servstart -eq "Disabled") {
                UEXRDS_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] [WARNING] " + $_ + " (" + $servdispname + ") is in " + $servstatus + " state (StartType: " + $servstart + ").")
            } else {
                UEXRDS_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] " + $_ + " (" + $servdispname + ") is in " + $servstatus + " state (StartType: " + $servstart + ").")
            }
        }
        else {
            UEXRDS_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] [WARNING] " + $_ + " not found.")
        }
    }

#endregion Checking status of key services


#region Checking for RD Listener configuration
    "`n======================================================================`n" | Out-File -Append $diagfile

    UEXRDS_LogDiag $LogLevel.Normal "Checking Remote Desktop Listener configuration"
    " " | Out-File -Append $diagfile

    $Commands = @(
        "UEXRDS_CheckRegKeyValue 'HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp\' 'fEnableWinStation' '1'"
        "UEXRDS_CheckRegKeyValue 'HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp\' 'fAllowSecProtocolNegotiation' '1'"
        "UEXRDS_CheckRegKeyValue 'HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp\' 'PortNumber' '3389'"
        "UEXRDS_CheckRegKeyValue 'HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp\' 'SecurityLayer'"
        "UEXRDS_CheckRegKeyValue 'HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp\' 'MinEncryptionLevel'"
        "UEXRDS_CheckRegKeyValue 'HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp\' 'UserAuthentication' '1'"
        "UEXRDS_CheckRegKeyValue 'HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp\' 'MaxInstanceCount' '4294967295'"
        "UEXRDS_CheckRegKeyValue 'HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp\' 'Shadow'"
    )
    UEXRDS_RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$False -ShowError:$True

#endregion Checking for RD Listener configuration


#region Checking for process crash events
    "`n======================================================================`n" | Out-File -Append $diagfile

    UEXRDS_LogDiag $LogLevel.Normal "Checking for process crash events over the past 5 days"
    " " | Out-File -Append $diagfile
    UEXRDS_DiagProcessCrash

#endregion Checking for process crash events


#region Checking SSL configuration
    "`n======================================================================`n" | Out-File -Append $diagfile

    UEXRDS_LogDiag $LogLevel.Normal "Checking SSL configuration"
    " " | Out-File -Append $diagfile

    if (Test-Path 'HKLM:\SOFTWARE\Policies\Microsoft\Cryptography\Configuration\SSL\00010002') {
        if (UEXRDS_TestRegistryValue -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Cryptography\Configuration\SSL\00010002' -Value 'Functions') {
            $rdpkeyvalue1 = Get-ItemPropertyValue -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Cryptography\Configuration\SSL\00010002' -name "Functions"
            UEXRDS_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] [WARNING] Registry key 'HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Cryptography\Configuration\SSL\00010002\Functions' exists and has a value of: " + $rdpkeyvalue1)
        }
        else {
            UEXRDS_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] Registry key 'HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Cryptography\Configuration\SSL\00010002\Functions' not found."
        }

        if (UEXRDS_TestRegistryValue -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Cryptography\Configuration\SSL\00010002' -Value 'EccCurves') {
            $rdpkeyvalue2 = Get-ItemPropertyValue -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Cryptography\Configuration\SSL\00010002' -name "EccCurves"
            UEXRDS_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] [WARNING] Registry key 'HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Cryptography\Configuration\SSL\00010002\EccCurves' exists and has a value of: " + $rdpkeyvalue2)
        }
        else {
            UEXRDS_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] Registry key 'HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Cryptography\Configuration\SSL\00010002\EccCurves' not found."
        }

    } else {
        UEXRDS_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] Registry key 'HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Cryptography\Configuration\SSL\00010002' not found."
    }

#endregion Checking 'SSL Cipher Suite Order' configuration


#region Checking for proxy settings
    "`n======================================================================`n" | Out-File -Append $diagfile

    UEXRDS_LogDiag $LogLevel.Normal "Checking for proxy configuration"
    " " | Out-File -Append $diagfile

    $binval = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Internet Settings\Connections" -Name WinHttpSettings).WinHttPSettings
    $proxylength = $binval[12]
    if ($proxylength -gt 0) {
        $proxy = -join ($binval[(12+3+1)..(12+3+1+$proxylength-1)] | ForEach-Object {([char]$_)})
        UEXRDS_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] [WARNING] A NETSH WINHTTP proxy is configured: " + $proxy)
        $bypasslength = $binval[(12+3+1+$proxylength)]

        if ($bypasslength -gt 0) {
            $bypasslist = -join ($binval[(12+3+1+$proxylength+3+1)..(12+3+1+$proxylength+3+1+$bypasslength)] | ForEach-Object {([char]$_)})
            UEXRDS_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] [WARNING] Bypass list: " + $bypasslist)
        } else {
            UEXRDS_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] [WARNING] No bypass list is configured."
        }
    } else {
        UEXRDS_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] NETSH WINHTTP proxy configuration not found."
    }

    $Commands = @(
        "UEXRDS_CheckRegKeyValue 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Internet Settings\' 'ProxyEnable'"
        "UEXRDS_CheckRegKeyValue 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Internet Settings\' 'ProxyServer'"
        "UEXRDS_CheckRegKeyValue 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Internet Settings\' 'ProxyOverride'"
        "UEXRDS_CheckRegKeyValue 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Internet Settings\' 'AutoConfigURL'"
    )
    UEXRDS_RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$False -ShowError:$True

#endregion Checking for proxy settings


#region Checking for Session Time Limit policy configuration
    "`n======================================================================`n" | Out-File -Append $diagfile

    UEXRDS_LogDiag $LogLevel.Normal "Checking for Session Time Limit policy configuration"
    " " | Out-File -Append $diagfile

    $Commands = @(
        "UEXRDS_CheckRegKeyValue 'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services\' 'MaxIdleTime'"
        "UEXRDS_CheckRegKeyValue 'HKCU:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services\' 'MaxIdleTime'"
        "UEXRDS_CheckRegKeyValue 'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services\' 'MaxConnectionTime'"
        "UEXRDS_CheckRegKeyValue 'HKCU:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services\' 'MaxConnectionTime'"
        "UEXRDS_CheckRegKeyValue 'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services\' 'MaxDisconnectionTime'"
        "UEXRDS_CheckRegKeyValue 'HKCU:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services\' 'MaxDisconnectionTime'"
        "UEXRDS_CheckRegKeyValue 'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services\' 'RemoteAppLogoffTimeLimit'"
        "UEXRDS_CheckRegKeyValue 'HKCU:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services\' 'RemoteAppLogoffTimeLimit'"
        "UEXRDS_CheckRegKeyValue 'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services\' 'fResetBroken'"
        "UEXRDS_CheckRegKeyValue 'HKCU:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services\' 'fResetBroken'"
    )
    UEXRDS_RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$False -ShowError:$True

#endregion Checking for Session Time Limit policy configuration


#region Checking for device redirection policy configuration
    "`n======================================================================`n" | Out-File -Append $diagfile

    UEXRDS_LogDiag $LogLevel.Normal "Checking for device and resource redirection policy configuration"
    " " | Out-File -Append $diagfile

    $Commands = @(
        "UEXRDS_CheckRegKeyValue 'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services\' 'fDisableAudioCapture' '' '(Allow audio recording redirection policy)'"
        "UEXRDS_CheckRegKeyValue 'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services\' 'fDisableAudioCam' '' '(Allow audio and video playback redirection policy)'"
        "UEXRDS_CheckRegKeyValue 'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services\' 'fEnableTimeZoneRedirection' '' '(Allow time zone redirection policy - machine wide)'"
        "UEXRDS_CheckRegKeyValue 'HKCU:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services\' 'fEnableTimeZoneRedirection' '' '(Allow time zone redirection policy - user specific)'"
        "UEXRDS_CheckRegKeyValue 'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services\' 'fDisableCdm' '' '(Do not allow drive redirection policy)'"
        "UEXRDS_CheckRegKeyValue 'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services\' 'fDisableClip' '' '(Do not allow clipboard redirection policy - machine wide)'"
        "UEXRDS_CheckRegKeyValue 'HKCU:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services\' 'fDisableClip' '' '(Do not allow clipboard redirection policy - user specific)'"
        "UEXRDS_CheckRegKeyValue 'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services\' 'fDisableCcm' '' '(Do not allow COM port redirection policy)'"
        "UEXRDS_CheckRegKeyValue 'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services\' 'fDisableLPT' '' '(Do not allow LPT port redirection policy)'"
        "UEXRDS_CheckRegKeyValue 'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services\' 'fEnableSmartCard' '' '(Do not allow smart card device redirection policy)'"
        "UEXRDS_CheckRegKeyValue 'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services\' 'fDisablePNPRedir' '' '(Do not allow supported Plug and Play device redirection policy)'"
        "UEXRDS_CheckRegKeyValue 'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services\' 'fDisableCameraRedir' '' '(Do not allow video capture redirection policy)'"
    )
    UEXRDS_RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$False -ShowError:$True

#endregion Checking for device redirection policy configuration


#region Checking camera/microphone privacy settings (general and desktop apps)
    "`n======================================================================`n" | Out-File -Append $diagfile

    UEXRDS_LogDiag $LogLevel.Normal "Checking camera and microphone privacy settings"
    " " | Out-File -Append $diagfile
    
    if (!($ver -like "*Windows 7*") -or !($ver -like "*Server 2008*")) {
        $Commands = @(
            "UEXRDS_CheckRegKeyValue 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\microphone\' 'Value' '' '(general)'"
            "UEXRDS_CheckRegKeyValue 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\microphone\NonPackaged\' 'Value' '' '(desktop apps)'"
            "UEXRDS_CheckRegKeyValue 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\webcam\' 'Value' '' '(general)'"
            "UEXRDS_CheckRegKeyValue 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\webcam\NonPackaged\' 'Value' '' '(desktop apps)'"
        )
        UEXRDS_RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$False -ShowError:$True
    } else {
        UEXRDS_LogDiag $LogLevel.Warning ("[$LogPrefix] Skipping check (not applicable for this OS version).")
    }

#endregion Checking media optimization configuration for Teams


#region Checking FSLogix settings
    "`n======================================================================`n" | Out-File -Append $diagfile

    UEXRDS_LogDiag $LogLevel.Normal "Checking FSLogix settings"
    " " | Out-File -Append $diagfile

    $cmd = "c:\program files\fslogix\apps\frx.exe"

    if (Test-path -path 'C:\Program Files\FSLogix\apps') {
        Invoke-Expression "& '$cmd' + 'version'" | ForEach-Object -Process {
            UEXRDS_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] " + $_)
            if ($_ -like "*Service*") {
                $frxver = ($_.Split(":")[1]).Trim()
            }
        }

        if (UEXRDS_TestRegistryValue -path "HKLM:\SOFTWARE\FSLogix\Profiles\" -value "Enabled") {
            $pOn = Get-ItemPropertyValue -Path "HKLM:\SOFTWARE\FSLogix\Profiles\" -name "Enabled"
            UEXRDS_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] FSLogix Profiles container 'Enabled' registry key found and has a value of: " + $pOn)

            if (UEXRDS_TestRegistryValue -path "HKLM:\SOFTWARE\FSLogix\Profiles\" -value "VHDLocations") {
                $pvhd = Get-ItemPropertyValue -Path "HKLM:\SOFTWARE\FSLogix\Profiles\" -name "VHDLocations"
                UEXRDS_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] FSLogix Profiles container 'VHDLocations' registry key found and has a value of: " + $pvhd)
            } else {
                UEXRDS_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] [WARNING] FSLogix Profile Container 'VHDLocations' registry key not found.")
            }

            if (UEXRDS_TestRegistryValue -path "HKLM:\SOFTWARE\FSLogix\Profiles\" -value "CCDLocations") {
                $pccd = Get-ItemPropertyValue -Path "HKLM:\SOFTWARE\FSLogix\Profiles\" -name "CCDLocations"
                UEXRDS_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] FSLogix Cloud Cache for Profile Container 'CCDLocations' registry key found and has a value of: " + $pccd)
            } else {
                UEXRDS_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] FSLogix Cloud Cache for Profile Container 'CCDLocations' registry key not found.")
            }

            if ((UEXRDS_TestRegistryValue -path "HKLM:\SOFTWARE\FSLogix\Profiles\" -value "VHDLocations") -and (UEXRDS_TestRegistryValue -path "HKLM:\SOFTWARE\FSLogix\Profiles\" -value "CCDLocations")) {
                UEXRDS_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] [WARNING] Both Profile VHDLocations and Profile Cloud Cache CCDLocations registry keys are present. If you want to use Profile Cloud Cache, remove any setting for Profile 'VHDLocations'. See https://docs.microsoft.com/en-us/fslogix/configure-cloud-cache-tutorial#configure-cloud-cache-for-smb")
            }

        } else {
            UEXRDS_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] [WARNING] FSLogix Profile Container 'Enabled' registry key not found. Profile container is not enabled.")
        }

        if (UEXRDS_TestRegistryValue -path "HKLM:\SOFTWARE\Policies\FSLogix\ODFC\" -value "Enabled") {
            $oOn = Get-ItemPropertyValue -Path "HKLM:\SOFTWARE\Policies\FSLogix\ODFC\" -name "Enabled"
            UEXRDS_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] FSLogix Office container 'Enabled' registry key found and has a value of: " + $oOn)

            if (UEXRDS_TestRegistryValue -path "HKLM:\SOFTWARE\Policies\FSLogix\ODFC\" -value "VHDLocations") {
                $ovhd = Get-ItemPropertyValue -Path "HKLM:\SOFTWARE\Policies\FSLogix\ODFC\" -name "VHDLocations"
                UEXRDS_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] FSLogix Office container 'VHDLocations' registry key found and has a value of: " + $ovhd)
            } else {
                UEXRDS_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] [WARNING] FSLogix Office Container 'VHDLocations' registry key not found.")
            }

            if (UEXRDS_TestRegistryValue -path "HKLM:\SOFTWARE\Policies\FSLogix\ODFC\" -value "CCDLocations") {
                $occd = Get-ItemPropertyValue -Path "HKLM:\SOFTWARE\Policies\FSLogix\ODFC\" -name "CCDLocations"
                UEXRDS_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] FSLogix Cloud Cache for Office Container 'CCDLocations' registry key found and has a value of: " + $occd)
            } else {
                UEXRDS_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] FSLogix Cloud Cache for Office Container 'CCDLocations' registry key not found.")
            }

            if ((UEXRDS_TestRegistryValue -path "HKLM:\SOFTWARE\Policies\FSLogix\ODFC\" -value "VHDLocations") -and (UEXRDS_TestRegistryValue -path "HKLM:\SOFTWARE\Policies\FSLogix\ODFC\" -value "CCDLocations")) {
                UEXRDS_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] [WARNING] Both Office VHDLocations and Office Cloud Cache CCDLocations registry keys are present. If you want to use Office Cloud Cache, remove any setting for Office 'VHDLocations'. See https://docs.microsoft.com/en-us/fslogix/configure-cloud-cache-tutorial#configure-cloud-cache-for-smb")
            }

        } else {
            UEXRDS_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] [WARNING] FSLogix Office Container 'Enabled' registry key not found. Office Container is not enabled.")
        }

        $frxver = $frxver.Replace(".","")
        if ($frxver -ge 29762130127) {
            $Commands = @(
                "UEXRDS_CheckRegKeyValue 'HKLM:\SOFTWARE\FSLogix\Apps\' 'CleanupInvalidSessions' '1'"
            )
            UEXRDS_RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$False -ShowError:$True
        } else {
            UEXRDS_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] FSLogix release earlier than release 2009 found. Please update FSLogix to the latest version. Review: https://docs.microsoft.com/en-us/fslogix/whats-new"
        }

        $Commands = @(
            "UEXRDS_CheckRegKeyValue 'HKLM:\SOFTWARE\FSLogix\Profiles\' 'DeleteLocalProfileWhenVHDShouldApply' '1'"
            "UEXRDS_CheckRegKeyValue 'HKLM:\SOFTWARE\FSLogix\Profiles\' 'SizeInMBs' '30000'"
            "UEXRDS_CheckRegKeyValue 'HKLM:\SOFTWARE\FSLogix\Profiles\' 'VolumeType' 'VHDx'"
            "UEXRDS_CheckRegKeyValue 'HKLM:\SOFTWARE\FSLogix\Profiles\' 'FlipFlopProfileDirectoryName' '1'"
            "UEXRDS_CheckRegKeyValue 'HKLM:\SOFTWARE\FSLogix\Profiles\' 'NoProfileContainingFolder' '0'"
        )
        UEXRDS_RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$False -ShowError:$True

        UEXRDS_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] FSLogix service recovery settings:"
        $commandline = "sc.exe qfailure frxsvc"
        $out = Invoke-Expression -Command $commandline
        foreach ($outopt in $out) {
            if (!($outopt -like "*QueryServiceConfig*")) {
                $outopt | Out-File -Append $DiagFile
            }
        }

    } else {
        UEXRDS_LogDiag $LogLevel.Warning "[$LogPrefix] FSLogix not found. Skipping check (not applicable)."
    }

#endregion Checking FSLogix settings


#region Checking for known FSLogix issues
    "`n======================================================================`n" | Out-File -Append $diagfile

    UEXRDS_LogDiag $LogLevel.Normal "Checking for known FSLogix issues over the past 5 days"
    " " | Out-File -Append $diagfile

    if (Test-path -path 'C:\Program Files\FSLogix\apps') {
        $Global:FSLogixIssues = 0
        $Commands = @(
            "UEXRDS_DiagIssues 'FSLogix' 'Microsoft-FSLogix-Apps/Operational' '26' 'Failed to open virtual disk'"
            "UEXRDS_DiagIssues 'FSLogix' 'Microsoft-FSLogix-Apps/Operational' '26' 'FindFile failed for path'"
            "UEXRDS_DiagIssues 'FSLogix' 'Microsoft-FSLogix-Apps/Operational' '26' 'LoadProfile failed'"
            "UEXRDS_DiagIssues 'FSLogix' 'System' '4' 'The Kerberos client received a KRB_AP_ERR_MODIFIED error from the server'"
        )
        UEXRDS_RunCommands $LogPrefix $Commands -ThrowException:$False -ShowMessage:$False -ShowError:$True
        if ($Global:FSLogixIssues -gt 0) {
            UEXRDS_LogDiag $LogLevel.DiagFileOnly "... [WARNING] See RDS-Diag-FSLogixIssuesEvents.txt for more information."
        } else {
            UEXRDS_LogDiag $LogLevel.DiagFileOnly "... The script ran checks for 4 known FSLogix issues and none of them have been found on this system. You should still investigate further if you suspect an FSLogix issue."
        }
    } else {
        UEXRDS_LogDiag $LogLevel.Warning "... FSLogix not found. Skipping check (not applicable)."
    }

#endregion Checking for known FSLogix issues


#region Checking for recommended Windows Defender configuration for Server OS (only if server OS is detected)
    if ($ver -like "*Windows Server*") {
    "`n======================================================================`n" | Out-File -Append $diagfile

    UEXRDS_LogDiag $LogLevel.Normal "Checking for recommended Windows Defender configuration for Server OS"
    " " | Out-File -Append $diagfile
    
        $WDpath = "HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\"
        $WDkey = "DisableAntiSpyware"
        if (UEXRDS_TestRegistryValue -path $WDpath -value $WDkey) {
            (Get-ItemProperty -path $WDpath).PSChildName | foreach-object -process {
                $key = Get-ItemPropertyValue -Path $WDpath -name $WDkey

                if ($key -eq $True) {
                    UEXRDS_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] [WARNING] Registry key '$WDpath$WDkey' exists and is set to 'True'. It is not recommended to disable Windows Defender, unless you are using another Antivirus software. Please see https://docs.microsoft.com/en-us/windows-hardware/customize/desktop/unattend/security-malware-windows-defender-disableantispyware")
                }
                else {
                    UEXRDS_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] Registry key '$WDpath$WDkey' exists and is set to 'False'.")
                }
            }
        } else {
            UEXRDS_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] Registry key '$WDpath$WDkey' not found.")
        }
    }

#endregion Checking for recommended Windows Defender configuration for Server OS


#region Checking for proper Defender Exclusions for FSLogix
    "`n======================================================================`n" | Out-File -Append $diagfile

    UEXRDS_LogDiag $LogLevel.Normal "Checking for recommended Windows Defender Exclusions for FSLogix"
    " " | Out-File -Append $diagfile

    if (Test-path -path 'C:\Program Files\FSLogix\apps') {

        #checking for actual Profiles VHDLocations value
        $pVHDpath = "HKLM:\SOFTWARE\FSLogix\Profiles\"
        $pVHDkey = "VHDLocations"
        if (UEXRDS_TestRegistryValue -path $pVHDpath -value $pVHDkey) {
            $pkey = (Get-ItemPropertyValue -Path $pVHDpath -name $pVHDkey).replace("`n","")
            $pkey1 = $pkey + "\*.VHD"
            $pkey2 = $pkey + "\*.VHDX"
        } else {
            #no path found, defaulting to generic value
            $pkey1 = "\\<storageaccount>.file.core.windows.net\<share>\*.VHD"
            $pkey2 = "\\<storageaccount>.file.core.windows.net\<share>\*.VHDX"
        }

        $ccdVHDkey = "CCDLocations"
        if (UEXRDS_TestRegistryValue -path $pVHDpath -value $ccdVHDkey) {
            $ccdkey = $True
        } else {
            $ccdkey = $false
        }

        $ccdRec = "%ProgramData%\FSLogix\Cache\*.VHD","%ProgramData%\FSLogix\Cache\*.VHDX","%ProgramData%\FSLogix\Proxy\*.VHD","%ProgramData%\FSLogix\Proxy\*.VHDX"
        $avRec = "%ProgramFiles%\FSLogix\Apps\frxdrv.sys","%ProgramFiles%\FSLogix\Apps\frxdrvvt.sys","%ProgramFiles%\FSLogix\Apps\frxccd.sys","%TEMP%\*.VHD","%TEMP%\*.VHDX","%Windir%\TEMP\*.VHD","%Windir%\TEMP\*.VHDX"

        UEXRDS_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] The tool is comparing the Windows Defender exclusion settings with the recommended settings. See https://docs.microsoft.com/en-us/azure/architecture/example-scenario/WVD/windows-virtual-desktop-fslogix#antivirus-exclusions"
        UEXRDS_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] The recommendations might change over time, so verify them periodically and ensure that you are using the latest recommendations."
        UEXRDS_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] The recommended values could be configured through UI or GPO. They should be present at least in one of the locations."

        " " | Out-File -Append $diagfile

        if ($ccdkey) {
            $recAVexclusionsPaths = $avRec + $pkey1 + $pkey2 + $ccdRec
        } else {
            $recAVexclusionsPaths = $avRec + $pkey1 + $pkey2
            UEXRDS_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] Cloud Cache is not enabled. The recommended Cloud Cache Exclusions will not be taken into consideration for this check. This may lead to false positives if you have the Cloud Cache Exclusions configured."
        }

        UEXRDS_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] Windows Defender Paths exclusions (UI configuration)"
        UEXRDS_TestAVExclusion "HKLM:\SOFTWARE\Microsoft\Windows Defender\Exclusions\Paths" $recAVexclusionsPaths
        UEXRDS_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] Windows Defender Paths exclusions (GPO configuration)"
        UEXRDS_TestAVExclusion "HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Exclusions\Paths" $recAVexclusionsPaths

        " " | Out-File -Append $diagfile
        UEXRDS_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] Windows Defender Processes exclusions (UI configuration)"
        UEXRDS_TestAVExclusion "HKLM:\SOFTWARE\Microsoft\Windows Defender\Exclusions\Processes" ("%ProgramFiles%\FSLogix\Apps\frxccd.exe","%ProgramFiles%\FSLogix\Apps\frxccds.exe","%ProgramFiles%\FSLogix\Apps\frxsvc.exe")
        UEXRDS_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] Windows Defender Processes exclusions (GPO configuration)"
        UEXRDS_TestAVExclusion "HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Exclusions\Processes" ("%ProgramFiles%\FSLogix\Apps\frxccd.exe","%ProgramFiles%\FSLogix\Apps\frxccds.exe","%ProgramFiles%\FSLogix\Apps\frxsvc.exe")

    } else {
        UEXRDS_LogDiag $LogLevel.Warning "[$LogPrefix] FSLogix not found. Skipping check (not applicable)."
    }

#endregion Checking for proper Defender Exclusions for FSLogix


#region Checking WinRM configuration
    "`n======================================================================`n" | Out-File -Append $diagfile

    UEXRDS_LogDiag $LogLevel.Normal "Checking WinRM configuration"
    " " | Out-File -Append $diagfile

    if ((get-service -name WinRM).status -eq "Running") {
            $ipfilter = Get-Item WSMan:\localhost\Service\IPv4Filter
            if ($ipfilter.Value) {
                if ($ipfilter.Value -eq "*") {
                    UEXRDS_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] IPv4Filter = *"
                } else {
                    UEXRDS_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] [WARNING] IPv4Filter = " + $ipfilter.Value)
                }
            } else {
                UEXRDS_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] [WARNING] IPv4Filter is empty, WinRM will not listen on IPv4.")
            }

            $ipfilter = Get-Item WSMan:\localhost\Service\IPv6Filter
            if ($ipfilter.Value) {
                if ($ipfilter.Value -eq "*") {
                    UEXRDS_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] IPv6Filter = *"
                } else {
                    UEXRDS_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] [WARNING] IPv6Filter = " + $ipfilter.Value)
                }
            } else {
                    UEXRDS_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] [WARNING] IPv6Filter is empty, WinRM will not listen on IPv6.")
            }
        } else {
            UEXRDS_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] [WARNING] The WinRM service is not running.")
        }

    if (!($ver -like "*Windows 7*") -or !($ver -like "*Server 2008*")) {
        $fwrules = (Get-NetFirewallPortFilter –Protocol TCP | Where-Object { $_.localport –eq ‘5985’ } | Get-NetFirewallRule)
        if ($fwrules.count -eq 0) {
          UEXRDS_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] No firewall rule for port 5985."
        } else {
          UEXRDS_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] Found firewall rule for port 5985. Check the 'FirewallRules.txt' file for more details."
        }


        $fwrules = (Get-NetFirewallPortFilter –Protocol TCP | Where-Object { $_.localport –eq ‘5986’ } | Get-NetFirewallRule)
        if ($fwrules.count -eq 0) {
          UEXRDS_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] No firewall rule for port 5986."
        } else {
          UEXRDS_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] Found firewall rule for port 5986. Check the 'FirewallRules.txt' file for more details."
        }
    } else {
        UEXRDS_LogDiag $LogLevel.Warning "[$LogPrefix] Skipping firewall port check. (not implemented yet for this OS version)"
    }

#endregion Checking WinRM configuration

#region Checking the WinRMRemoteWMIUsers__ group"
    if ((get-ciminstance -Class Win32_ComputerSystem).PartOfDomain) {
        UEXRDS_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] Checking the WinRMRemoteWMIUsers__ group"
        $search = New-Object DirectoryServices.DirectorySearcher([ADSI]"")  # This is a Domain local group, therefore we need to collect to a non-global catalog
        $search.filter = "(samaccountname=WinRMRemoteWMIUsers__)"
        try {
            $results = $search.Findall()
        } catch {
            $_ | Out-File -Append -FilePath $ErrorLogFile
        }

        if ($results.count -gt 0) {
            UEXRDS_LogDiag $LogLevel.DiagFileOnly ("[$LogPrefix] Found " + $results.Properties.distinguishedname)
            if ($results.Properties.grouptype -eq  -2147483644) {
                UEXRDS_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] WinRMRemoteWMIUsers__ is a Domain local group."
            } elseif ($results.Properties.grouptype -eq -2147483646) {
                UEXRDS_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] [WARNING] WinRMRemoteWMIUsers__ is a Global group."
            } elseif ($results.Properties.grouptype -eq -2147483640) {
                UEXRDS_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] [WARNING] WinRMRemoteWMIUsers__ is a Universal group."
            }
            if (get-ciminstance -query "select * from Win32_Group where Name = 'WinRMRemoteWMIUsers__' and Domain = '$env:computername'") {
                UEXRDS_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] The group WinRMRemoteWMIUsers__ is also present as machine local group."
            }
        } else {
            UEXRDS_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] The WinRMRemoteWMIUsers__ was not found in the domain."
            if (get-ciminstance -query "select * from Win32_Group where Name = 'WinRMRemoteWMIUsers__' and Domain = '$env:computername'") {
                UEXRDS_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] The group WinRMRemoteWMIUsers__ is present as machine local group."
            } else {
                UEXRDS_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] WinRMRemoteWMIUsers__ group not found as machine local group."
            }
        }
    } else {
        UEXRDS_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] [WARNING] The machine is not joined to a domain."
        if (get-ciminstance -query "select * from Win32_Group where Name = 'WinRMRemoteWMIUsers__' and Domain = '$env:computername'") {
            UEXRDS_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] The group WinRMRemoteWMIUsers__ is present as machine local group."
        } else {
            UEXRDS_LogDiag $LogLevel.DiagFileOnly "[$LogPrefix] WinRMRemoteWMIUsers__ group not found as machine local group."
        }
    }

#endregion Checking the WinRMRemoteWMIUsers__ group"


    " " | Out-File -Append $diagfile
    " " | Out-File -Append $diagfile
    "`n======================================================================`n" | Out-File -Append $diagfile
    "`nReport generated with script version: $version (Get the latest version from https://aka.ms/rds-collect)" | Out-File -Append $diagfile

    #Generating RDS-Diag to HTML file
    $SourceFile = ($BasicLogFolder + "RDS-Diag.txt")
    $TargetFile = ($BasicLogFolder + "RDS-Diag.html")
    $Title = "RDS-Diag : " + $env:computername

    $File = Get-Content $SourceFile
    $FileLine = @()
    Foreach ($Line in $File) {
        $MyObject = New-Object -TypeName PSObject
        Add-Member -InputObject $MyObject -Type NoteProperty -Name "RDS CSS Diagnostics" -Value $Line
        $FileLine += $MyObject
    }

    $FileLine | ConvertTo-Html -Title $Title -body $bodyDiag -Property "RDS CSS Diagnostics" | ForEach-Object {

        $PSItem -replace "RDS CSS Diagnostics","<a name='TopDiag'></a><br>RDS CSS Diagnostics<br><br>" `
        -replace "WARNING","<span style='background-color: #FFFF00'>WARNING</span>" `
        -replace "Skipping check","<span style='color: brown'>Skipping check</span>" `
        -replace "not found","<span style='color: brown'>not found</span>" `
        -replace "is in Running state","is in <span style='color: green'>Running</span> state" `
        -replace "is in Stopped state","is in <span style='color: blue'>Stopped</span> state" `
        -replace "is in Disabled state","is in <span style='background-color: #FFFF00'>Disabled</span> state" `
        -replace "RDS-Diag-ProcessCrashEvents.txt","<span style='font-weight: bold'>RDS-Diag-ProcessCrashEvents.txt</span>" `
        -replace "======================================================================","<p style='font-size:small;text-align:right'>^<a href='#TopDiag'>top</a> </p><hr><br>" `
        -replace "https://docs.microsoft.com/en-us/fslogix/configure-cloud-cache-tutorial#configure-cloud-cache-for-smb", "<a href='https://docs.microsoft.com/en-us/fslogix/configure-cloud-cache-tutorial#configure-cloud-cache-for-smb' target='_blank'>https://docs.microsoft.com/en-us/fslogix/configure-cloud-cache-tutorial#configure-cloud-cache-for-smb</a>" `
        -replace "https://docs.microsoft.com/en-us/azure/architecture/example-scenario/WVD/windows-virtual-desktop-fslogix#antivirus-exclusions","<a href='https://docs.microsoft.com/en-us/azure/architecture/example-scenario/WVD/windows-virtual-desktop-fslogix#antivirus-exclusions' target='_blank'>https://docs.microsoft.com/en-us/azure/architecture/example-scenario/WVD/windows-virtual-desktop-fslogix#antivirus-exclusions</a>" `
        -replace "https://support.microsoft.com/en-us/help/4490481","<a href='https://support.microsoft.com/en-us/help/4490481' target='_blank'>https://support.microsoft.com/en-us/help/4490481</a>" `
        -replace "Checking system/deployment","<a name='SystemCheck'></a><b>Checking system/deployment</b>" `
        -replace "Checking for installed RDS roles","<a name='RolesCheck'></a><b>Checking for installed RDS roles</b>" `
        -replace "Checking licensing configuration for RD Session Host","<a name='RDSHlicCheck'></a><b>Checking licensing configuration for RD Session Host</b>" `
        -replace "Checking for device and resource redirection policy configuration","<a name='Redirection'></a><b>Checking for device and resource redirection policy configuration</b>" `
        -replace "Checking for graphics configuration","<a name='GPUCheck'></a><b>Checking for graphics configuration</b>" `
        -replace "Checking status of key services","<a name='ServicesCheck'></a><b>Checking status of key services</b>" `
        -replace "Checking Remote Desktop Listener configuration","<a name='ListenerCheck'></a><b>Checking Remote Desktop Listener configuration</b>" `
        -replace "Checking for proxy configuration","<a name='ProxyCheck'></a><b>Checking for proxy configuration</b>" `
        -replace "Checking SSL configuration","<a name='SSLCheck'></a><b>Checking SSL configuration</b>" `
        -replace "Checking for Session Time Limit policy configuration","<a name='STLCheck'></a><b>Checking for Session Time Limit policy configuration</b>" `
        -replace "Checking WinRM configuration","<a name='WinRMCheck'></a><b>Checking WinRM configuration</b>" `
        -replace "Checking for process crash events over the past 5 days","<a name='CrashCheck'></a><b>Checking for process crash events over the past 5 days</b>" `
        -replace "Checking FSLogix settings", "<a name='FSLogixCheck'></a><b>Checking FSLogix settings</b>" `
        -replace "Checking for recommended Windows Defender Exclusions for FSLogix","<a name='DefenderCheck'></a><b>Checking for recommended Windows Defender Exclusions for FSLogix</b>" `
        -replace "Checking for recommended Windows Defender configuration for Server OS","<b>Checking for recommended Windows Defender configuration for Server OS</b>" `
        -replace "Checking camera and microphone privacy settings","<a name='PrivacyCheck'></a><b>Checking camera and microphone privacy settings</b>" `
        -replace "has a value of: Allow","has a value of: <span style='color: green'>Allow</span>" `
        -replace "has a value of: Deny","has a value of: <span style='color: red'>Deny</span>" `
        -replace "UI configuration","<span style='color: blue'>UI configuration</span>" `
        -replace "GPO configuration","<span style='color: blue'>GPO configuration</span>" `
        -replace "VHDLocations","<span style='color: blue'>VHDLocations</span>" `
        -replace "not enabled","<span style='color: brown'>not enabled</span>" `
        -replace "additional data collection and analysis may be required.","additional data collection and analysis may be required.<br><p style='font-size:small;text-align:center'><a href='#SystemCheck'>System</a> | <a href='#RolesCheck'>RDS Roles</a> | <a href='#RDSHlicCheck'>RDSH licensing</a> | <a href='#GPUCheck'>Graphics</a> | <a href='#ServicesCheck'>Services</a> | <a href='#ListenerCheck'>Listener</a> | <a href='#CrashCheck'>Crashes</a> | <a href='#SSLCheck'>SSL</a> | <a href='#ProxyCheck'>Proxy</a> | <a href='#STLCheck'>Session Time Limit</a> | <a href='#Redirection'>Redirection</a> | <a href='#PrivacyCheck'>Privacy</a> | <a href='#FSLogixCheck'>FSLogix</a> | <a href='#DefenderCheck'>Defender</a> | <a href='#WinRMCheck'>WinRM</a></p><br>" `
        -replace "RDSCollectTalk@microsoft.com","<a href='mailto:RDSCollectTalk@microsoft.com'>RDSCollectTalk@microsoft.com</a>" `
        -replace "https://support.microsoft.com/en-us/help/4000825", "<a href='https://support.microsoft.com/en-us/help/4000825' target='_blank'>https://support.microsoft.com/en-us/help/4000825</a>" `
        -replace "https://support.microsoft.com/en-us/help/4464619", "<a href='https://support.microsoft.com/en-us/help/4464619' target='_blank'>https://support.microsoft.com/en-us/help/4464619</a>" `
        -replace "https://support.microsoft.com/en-us/help/4529964", "<a href='https://support.microsoft.com/en-us/help/4529964' target='_blank'>https://support.microsoft.com/en-us/help/4529964</a>" `
        -replace "https://support.microsoft.com/en-us/help/4555932", "<a href='https://support.microsoft.com/en-us/help/4555932' target='_blank'>https://support.microsoft.com/en-us/help/4555932</a>" `
        -replace "https://support.microsoft.com/en-us/help/4581839", "<a href='https://support.microsoft.com/en-us/help/4581839' target='_blank'>https://support.microsoft.com/en-us/help/4581839</a>" `
        -replace "https://support.microsoft.com/en-us/help/5003498", "<a href='https://support.microsoft.com/en-us/help/5003498' target='_blank'>https://support.microsoft.com/en-us/help/5003498</a>" `
        -replace "https://aka.ms/rds-collect", "<a href='https://aka.ms/rds-collect' target='_blank'>https://aka.ms/rds-collect</a>"
       } | Out-File $TargetFile
}

#endregion Main functions

#endregion Functions


#region ####################### MAIN ########################

UEXRDS_LogMessage $LogLevel.Info "Starting RDS-Collect - v$version - https://aka.ms/rds-collect" -Color "Cyan"

if ($AcceptEula) {
    UEXRDS_LogMessage $LogLevel.Info ("AcceptEula switch specified, silently continuing")
    $eulaAccepted = ShowEULAIfNeeded "RDS-Collect" 2
  } else {
    $eulaAccepted = ShowEULAIfNeeded "RDS-Collect" 0
    if($eulaAccepted -ne "Yes")
     {
       UEXRDS_LogMessage $LogLevel.Info ("EULA declined, exiting")
       exit
     }
   }
UEXRDS_LogMessage $LogLevel.Info ("EULA accepted, continuing")

Write-Host "`n=============== Microsoft CSS Diagnostics Script ===============`n"
Write-Host "This Data Collection is for troubleshooting reported issues for the given scenarios."
Write-Host "Once you have started this script please wait until all data has been collected.`n`n"
Write-Host "======================= IMPORTANT NOTICE =======================`n"
Write-Host "This script is designed to collect information that will help Microsoft Customer Support Services (CSS) troubleshoot an issue you may be experiencing with Remote Desktop Services."
Write-Host "The collected data may contain Personally Identifiable Information (PII) and/or sensitive data, such as (but not limited to) IP addresses; PC names; and user names."
Write-Host "The script will save the collected data in a folder and also compress the results into a ZIP file, both in the same location from where the script has been launched."
Write-Host "This folder and its contents or the ZIP file are not automatically sent to Microsoft."
Write-Host "You can send the ZIP file to Microsoft CSS using a secure file transfer tool - Please discuss this with your support professional and also any concerns you may have."
Write-Host "Find our privacy statement here: https://privacy.microsoft.com/en-US/privacystatement`n"

$UserConsent = Read-Host -Prompt 'Are you sure you want to continue? [Y/N]'

if ($UserConsent.ToLower() -ne "y") {
    Write-Host "Script execution not approved by the admin user, exiting.`n"
    Remove-Item -path $LogDir -Recurse | Out-Null
    UEXRDS_CleanUpandExit
}

""
if (!($Core) -and !($Extended) -and !($DiagOnly) -and !($Profiles) -and !($MSRA)) {
    $title = "Please select one of the following RDS-Collect scenarios:"
    $message = "
        1) Collect 'Core' data (does not include Profiles/MSRA data) + Run Diagnostics`n
        2) Collect 'Core + Profiles' data (for troubleshooting Profiles scenarios) + Run Diagnostics`n
        3) Collect 'Core + MSRA' data (for troubleshooting Remote Assistance scenarios) + Run Diagnostics`n
        4) Collect 'Extended' (all) troubleshooting data (includes Core + all other categories) + Run Diagnostics`n
        5) Run 'Diagnostics' only (skip data collection - may still log process crash related events, if found)`n"

    $optCore = New-Object System.Management.Automation.Host.ChoiceDescription ' &1-Core ', 'The tool will collect core troubleshooting data without Profiles/MSRA related information'
    $optProfiles = New-Object System.Management.Automation.Host.ChoiceDescription ' &2-Profiles ', 'The tool will collect all troubleshooting data included in the Core scenario and Profiles/FSLogix related data, as available'
    $optMsra = New-Object System.Management.Automation.Host.ChoiceDescription ' &3-MSRA ', 'The tool will collect all troubleshooting data included in the Core scenario and Remote Assistance related data, as available'
    $optAll = New-Object System.Management.Automation.Host.ChoiceDescription ' &4-Extended ', 'The tool will collect all troubleshooting data included in the Core scenario and also Profiles/MSRA related information, as available'
    $optDiag = New-Object System.Management.Automation.Host.ChoiceDescription ' &5-DiagOnly ', 'The tool will only run Diagnostics and log the results. It may also log process crash related events, if found.'

    $options = [System.Management.Automation.Host.ChoiceDescription[]]($optCore, $optProfiles, $optMsra, $optAll, $optDiag)
    $result = $host.ui.PromptForChoice($title, $message, $options, 0)

    switch ($result) {
        0 {
            UEXRDS_LogMessage $LogLevel.Info ("'Core' scenario selected.")
            $Core = $True
        }
        1 {
            UEXRDS_LogMessage $LogLevel.Info ("'Core + Profiles' scenario selected.")
            $Profiles = $True
        }
        2 {
            UEXRDS_LogMessage $LogLevel.Info ("'Core + MSRA' scenario selected.")
            $MSRA = $True
          }
        3 {
            UEXRDS_LogMessage $LogLevel.Info ("'All' scenario selected.")
            $Extended = $True
          }
        4 {
            UEXRDS_LogMessage $LogLevel.Info ("'Diagnostics Only' scenario selected.")
            $DiagOnly = $True
          }
    }
}

$StopWatchDC = [system.diagnostics.stopwatch]::startNew()
""
" " | Out-File -Append $OutputLogFile

if ($Extended -and !($DiagOnly)) {
    CollectUEX_RDSCoreLog
    CollectUEX_RDSProfilesLog
    CollectUEX_RDSMSRALog
}

if (!($Extended) -and !($DiagOnly)) {
    CollectUEX_RDSCoreLog
    if ($Profiles) { CollectUEX_RDSProfilesLog }
    if ($MSRA) { CollectUEX_RDSMSRALog }
}

RunUEX_RDSDiag

#endregion MAIN


#region ####################### Archive results ########################

$StopWatchDC.Stop()
$tsDC =  [timespan]::fromseconds(($StopWatchDC.Elapsed).TotalSeconds)
$elapsedDC = ("{0:hh\:mm\:ss\.fff}" -f $tsDC)
""
" " | Out-File -Append $OutputLogFile
UEXRDS_LogMessage $LogLevel.Info "Data collection complete - archiving files!" -Color "Cyan"
UEXRDS_LogMessage $LogLevel.Normal "Data collection duration (hh:mm:ss.fff): $elapsedDC`n"
$destination = $LogRoot + "\" + $LogFolder + ".zip"
Compress-Archive -Path $LogDir -DestinationPath $destination -CompressionLevel Optimal -Force

if (Test-path -path $destination) {
        UEXRDS_LogMessage $LogLevel.Normal "Zip file ready. Location of the collected data: $LogRoot\`n" -Color "Green"
    } else {
        UEXRDS_LogMessage $LogLevel.Error "Zip file could not be created. Please manually archive the subfolder containing the collected data. Location of the collected data: $LogRoot\`n"
    }
""
explorer $LogRoot

#endregion Archive

# Disabling quick edit mode as somethimes this causes the script stop working until enter key is pressed.
If ($fQuickEditCodeExist) { [DisableConsoleQuickEdit]::SetQuickEdit($True) | Out-Null }


# SIG # Begin signature block
# MIIjnAYJKoZIhvcNAQcCoIIjjTCCI4kCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCCQSg3OVvZXjefO
# /aAZH6PlUe7A0NYlbEUMWg4bDrKve6CCDYEwggX/MIID56ADAgECAhMzAAAB32vw
# LpKnSrTQAAAAAAHfMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjAxMjE1MjEzMTQ1WhcNMjExMjAyMjEzMTQ1WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC2uxlZEACjqfHkuFyoCwfL25ofI9DZWKt4wEj3JBQ48GPt1UsDv834CcoUUPMn
# s/6CtPoaQ4Thy/kbOOg/zJAnrJeiMQqRe2Lsdb/NSI2gXXX9lad1/yPUDOXo4GNw
# PjXq1JZi+HZV91bUr6ZjzePj1g+bepsqd/HC1XScj0fT3aAxLRykJSzExEBmU9eS
# yuOwUuq+CriudQtWGMdJU650v/KmzfM46Y6lo/MCnnpvz3zEL7PMdUdwqj/nYhGG
# 3UVILxX7tAdMbz7LN+6WOIpT1A41rwaoOVnv+8Ua94HwhjZmu1S73yeV7RZZNxoh
# EegJi9YYssXa7UZUUkCCA+KnAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUOPbML8IdkNGtCfMmVPtvI6VZ8+Mw
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDYzMDA5MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAnnqH
# tDyYUFaVAkvAK0eqq6nhoL95SZQu3RnpZ7tdQ89QR3++7A+4hrr7V4xxmkB5BObS
# 0YK+MALE02atjwWgPdpYQ68WdLGroJZHkbZdgERG+7tETFl3aKF4KpoSaGOskZXp
# TPnCaMo2PXoAMVMGpsQEQswimZq3IQ3nRQfBlJ0PoMMcN/+Pks8ZTL1BoPYsJpok
# t6cql59q6CypZYIwgyJ892HpttybHKg1ZtQLUlSXccRMlugPgEcNZJagPEgPYni4
# b11snjRAgf0dyQ0zI9aLXqTxWUU5pCIFiPT0b2wsxzRqCtyGqpkGM8P9GazO8eao
# mVItCYBcJSByBx/pS0cSYwBBHAZxJODUqxSXoSGDvmTfqUJXntnWkL4okok1FiCD
# Z4jpyXOQunb6egIXvkgQ7jb2uO26Ow0m8RwleDvhOMrnHsupiOPbozKroSa6paFt
# VSh89abUSooR8QdZciemmoFhcWkEwFg4spzvYNP4nIs193261WyTaRMZoceGun7G
# CT2Rl653uUj+F+g94c63AhzSq4khdL4HlFIP2ePv29smfUnHtGq6yYFDLnT0q/Y+
# Di3jwloF8EWkkHRtSuXlFUbTmwr/lDDgbpZiKhLS7CBTDj32I0L5i532+uHczw82
# oZDmYmYmIUSMbZOgS65h797rj5JJ6OkeEUJoAVwwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVcTCCFW0CAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAd9r8C6Sp0q00AAAAAAB3zAN
# BglghkgBZQMEAgEFAKCBrjAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQg3xn33jdt
# tGPnhkz3MPCJ4nr2VPr9jshvkOgYNQkKJCswQgYKKwYBBAGCNwIBDDE0MDKgFIAS
# AE0AaQBjAHIAbwBzAG8AZgB0oRqAGGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbTAN
# BgkqhkiG9w0BAQEFAASCAQBrSPBbpr/1ZYFb0rvculLzDdBMShwgFrmklVPlKAS7
# 9Yq2vEyYLo3kjDB9IUjgsWkzyoXfF0wdK/ng2JEh7zwTJ4Hi+TbbYUB7NvDgOgut
# bRWQaJddL3/dOLv+elDafdYt2mBAK0FAB/XfhV0s+HNwMFfzh1btC1EzRQzntuPD
# jGJyoftPXN87kJTGX9ceVsF7qCcdbHMGC4/p6c+mzBih/NVD1oogrMckrZs+Gvun
# qJiM+MweROq703Gr1V6UsNXbrhZt2eZ6w+0QIIBHwwAptNGEjoPpa13x8F8+8hhr
# 6nBiHEzA1gIV/4xIgs6HtSCvXdOpyCvUZKdIUzKPhjHKoYIS+zCCEvcGCisGAQQB
# gjcDAwExghLnMIIS4wYJKoZIhvcNAQcCoIIS1DCCEtACAQMxDzANBglghkgBZQME
# AgEFADCCAVkGCyqGSIb3DQEJEAEEoIIBSASCAUQwggFAAgEBBgorBgEEAYRZCgMB
# MDEwDQYJYIZIAWUDBAIBBQAEIPZ6Evbsc3btTFXAZ/29pUeTiZLIIDdZIBmEAJKf
# t3TwAgZhHtaXizgYEzIwMjEwODI0MTMzNjIyLjM1MVowBIACAfSggdikgdUwgdIx
# CzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRt
# b25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xLTArBgNVBAsTJE1p
# Y3Jvc29mdCBJcmVsYW5kIE9wZXJhdGlvbnMgTGltaXRlZDEmMCQGA1UECxMdVGhh
# bGVzIFRTUyBFU046MkFENC00QjkyLUZBMDExJTAjBgNVBAMTHE1pY3Jvc29mdCBU
# aW1lLVN0YW1wIFNlcnZpY2Wggg5KMIIE+TCCA+GgAwIBAgITMwAAATjzlCHWYb7w
# KQAAAAABODANBgkqhkiG9w0BAQsFADB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0Eg
# MjAxMDAeFw0yMDEwMTUxNzI4MjBaFw0yMjAxMTIxNzI4MjBaMIHSMQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQLEyRNaWNyb3NvZnQg
# SXJlbGFuZCBPcGVyYXRpb25zIExpbWl0ZWQxJjAkBgNVBAsTHVRoYWxlcyBUU1Mg
# RVNOOjJBRDQtNEI5Mi1GQTAxMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFt
# cCBTZXJ2aWNlMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAxbn4p6le
# cIMyAgKjbK7+A/vdqY+y1pmgXIjOwXGvDAjy7aKPsp978FH+VPHh+3Yk9tc0ET35
# 54bbS7TrObejbAH8bQ3UMqT7sU79nkALxKqykp2lYfI/ZvrDVBecswbz1v/9CZcT
# drSailbNDIg1lTfSA0LDhebTt02J+R5eCZrhfXedCWJP1kt1jy0E5wJUryqYOhXs
# rgewGdQsdH2bvp5JfRip+vg8rwVAJ78RHbbT5xTof+oFLOCAgmJG0e2yC7PAItEr
# KPMWjM86pkVKR6atoVKuA5oG4d4NWktiUzKT2bynwlVkx74uu6rF7U+56udCwwk2
# mnNjD+OXDhyPGQIDAQABo4IBGzCCARcwHQYDVR0OBBYEFN/qrdzo76xTsTL7OYjF
# YMGeccC1MB8GA1UdIwQYMBaAFNVjOlyKMZDzQ3t8RhvFM2hahW1VMFYGA1UdHwRP
# ME0wS6BJoEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1
# Y3RzL01pY1RpbVN0YVBDQV8yMDEwLTA3LTAxLmNybDBaBggrBgEFBQcBAQROMEww
# SgYIKwYBBQUHMAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMv
# TWljVGltU3RhUENBXzIwMTAtMDctMDEuY3J0MAwGA1UdEwEB/wQCMAAwEwYDVR0l
# BAwwCgYIKwYBBQUHAwgwDQYJKoZIhvcNAQELBQADggEBAKN4sEhcC7G/DRKQy9LI
# to5OI5VZUgS3SBFZrNHsr/ZzR5MsaiY3eVxm9zZmbg+m4utdCi8FcUdPScD6r8Fo
# tfHO3dF/I6rjXej/sGbNv7h8HsBPWmL3Se+mZ+//IQrFi5rktqxs6LSkCPirmMhY
# Z6hUfJgN4PgtkG/mwqSqF04f74G8A2JHwhDzsLBi4MYBZDT4KLJ9KAOgWZAmS4O3
# MAYxzsfbsN0WsjMgDMq8B2XqQNzILESwkAPRJKWXfX73C6IJS5MHWarGIj+BygDs
# 5p6M28w53sXPWAKNAqt7ZGBaspG+k/t3xfWAm8eD4CnvEKSVM8Vffr2HwG+CUgAC
# ppowggZxMIIEWaADAgECAgphCYEqAAAAAAACMA0GCSqGSIb3DQEBCwUAMIGIMQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNy
# b3NvZnQgUm9vdCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkgMjAxMDAeFw0xMDA3MDEy
# MTM2NTVaFw0yNTA3MDEyMTQ2NTVaMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpX
# YXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQg
# Q29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAy
# MDEwMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAqR0NvHcRijog7PwT
# l/X6f2mUa3RUENWlCgCChfvtfGhLLF/Fw+Vhwna3PmYrW/AVUycEMR9BGxqVHc4J
# E458YTBZsTBED/FgiIRUQwzXTbg4CLNC3ZOs1nMwVyaCo0UN0Or1R4HNvyRgMlhg
# RvJYR4YyhB50YWeRX4FUsc+TTJLBxKZd0WETbijGGvmGgLvfYfxGwScdJGcSchoh
# iq9LZIlQYrFd/XcfPfBXday9ikJNQFHRD5wGPmd/9WbAA5ZEfu/QS/1u5ZrKsajy
# eioKMfDaTgaRtogINeh4HLDpmc085y9Euqf03GS9pAHBIAmTeM38vMDJRF1eFpwB
# BU8iTQIDAQABo4IB5jCCAeIwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFNVj
# OlyKMZDzQ3t8RhvFM2hahW1VMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsG
# A1UdDwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFNX2VsuP6KJc
# YmjRPZSQW9fOmhjEMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9jcmwubWljcm9z
# b2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIz
# LmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6Ly93d3cubWlj
# cm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3J0
# MIGgBgNVHSABAf8EgZUwgZIwgY8GCSsGAQQBgjcuAzCBgTA9BggrBgEFBQcCARYx
# aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL1BLSS9kb2NzL0NQUy9kZWZhdWx0Lmh0
# bTBABggrBgEFBQcCAjA0HjIgHQBMAGUAZwBhAGwAXwBQAG8AbABpAGMAeQBfAFMA
# dABhAHQAZQBtAGUAbgB0AC4gHTANBgkqhkiG9w0BAQsFAAOCAgEAB+aIUQ3ixuCY
# P4FxAz2do6Ehb7Prpsz1Mb7PBeKp/vpXbRkws8LFZslq3/Xn8Hi9x6ieJeP5vO1r
# VFcIK1GCRBL7uVOMzPRgEop2zEBAQZvcXBf/XPleFzWYJFZLdO9CEMivv3/Gf/I3
# fVo/HPKZeUqRUgCvOA8X9S95gWXZqbVr5MfO9sp6AG9LMEQkIjzP7QOllo9ZKby2
# /QThcJ8ySif9Va8v/rbljjO7Yl+a21dA6fHOmWaQjP9qYn/dxUoLkSbiOewZSnFj
# nXshbcOco6I8+n99lmqQeKZt0uGc+R38ONiU9MalCpaGpL2eGq4EQoO4tYCbIjgg
# tSXlZOz39L9+Y1klD3ouOVd2onGqBooPiRa6YacRy5rYDkeagMXQzafQ732D8OE7
# cQnfXXSYIghh2rBQHm+98eEA3+cxB6STOvdlR3jo+KhIq/fecn5ha293qYHLpwms
# ObvsxsvYgrRyzR30uIUBHoD7G4kqVDmyW9rIDVWZeodzOwjmmC3qjeAzLhIp9cAv
# VCch98isTtoouLGp25ayp0Kiyc8ZQU3ghvkqmqMRZjDTu3QyS99je/WZii8bxyGv
# WbWu3EQ8l1Bx16HSxVXjad5XwdHeMMD9zOZN+w2/XU/pnR4ZOC+8z1gFLu8NoFA1
# 2u8JJxzVs341Hgi62jbb01+P3nSISRKhggLUMIICPQIBATCCAQChgdikgdUwgdIx
# CzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRt
# b25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xLTArBgNVBAsTJE1p
# Y3Jvc29mdCBJcmVsYW5kIE9wZXJhdGlvbnMgTGltaXRlZDEmMCQGA1UECxMdVGhh
# bGVzIFRTUyBFU046MkFENC00QjkyLUZBMDExJTAjBgNVBAMTHE1pY3Jvc29mdCBU
# aW1lLVN0YW1wIFNlcnZpY2WiIwoBATAHBgUrDgMCGgMVAEC86zs20AKnzakuISFL
# JspZ5oH5oIGDMIGApH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0
# b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3Jh
# dGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwDQYJ
# KoZIhvcNAQEFBQACBQDkz0OlMCIYDzIwMjEwODI0MTgwODM3WhgPMjAyMTA4MjUx
# ODA4MzdaMHQwOgYKKwYBBAGEWQoEATEsMCowCgIFAOTPQ6UCAQAwBwIBAAICBN4w
# BwIBAAICEy4wCgIFAOTQlSUCAQAwNgYKKwYBBAGEWQoEAjEoMCYwDAYKKwYBBAGE
# WQoDAqAKMAgCAQACAwehIKEKMAgCAQACAwGGoDANBgkqhkiG9w0BAQUFAAOBgQAn
# u1A6LJ3al2zjIrj78Ld/O8AUED9rAOLgvEygahuOdnaLoCUmEjF9Yib2vAU4pUM8
# 8sOFITD7FbYQw1zT0Q2wEFAEnXS7stnqIA+LEaWLqeTE37lpDGj1RyqyKG6oA5Bo
# Li9Ih/AHK0sQyHWZPxZ8OIgrLyZNR6/m/bEdBWDeBDGCAw0wggMJAgEBMIGTMHwx
# CzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRt
# b25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1p
# Y3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAABOPOUIdZhvvApAAAAAAE4
# MA0GCWCGSAFlAwQCAQUAoIIBSjAaBgkqhkiG9w0BCQMxDQYLKoZIhvcNAQkQAQQw
# LwYJKoZIhvcNAQkEMSIEIMbRATZcwLPRzq8zzu6lgMQUC0/UZg97ZQR9K47V6cxA
# MIH6BgsqhkiG9w0BCRACLzGB6jCB5zCB5DCBvQQgQ0CTSvl/RCqSSGLiLKbu7sbS
# 3mjmCOpO+ith7RaPhygwgZgwgYCkfjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0Eg
# MjAxMAITMwAAATjzlCHWYb7wKQAAAAABODAiBCB+lRvOLv8R/j45utJYJgcyQIeE
# eUtEt6PjlZg7Ini5gDANBgkqhkiG9w0BAQsFAASCAQAxwRqMZh03dMh7LqeRj8+R
# gPbMIf4KiWlvxRJZveDZgmuvfL+7CfDpWvCDffDhUhe5+ee1043LRpYdA5gYsV1D
# IAjQA4NJ8zfNUfxI5Sus5CHdtqQoJOAl8anH0kIZ82V5NHo8H0hPWR9jH0KdtlKg
# auCbSOt/SYQ+7BQY6ZFvzJNY8fl9ENuCdvtNdex3Ce3DONF2UJxk41RQN966Tah1
# OSqbWNRF+eS1xdZkiE97oFN+LynwT7J/ihRgTSZDZxzUuwkAoW4zQdbdosRVvmiB
# 66hcVO03P1giCkz5wz8FNF8UsbEihlLTdljf10Cas23rA8BHfytcvSm4FHponVWM
# SIG # End signature block
